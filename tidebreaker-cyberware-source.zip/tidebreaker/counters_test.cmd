@echo off
cd /d "%~dp0"
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 /WX counters_test.cpp /Fe:counters_test.exe
if errorlevel 1 exit /b 1
counters_test.exe
exit /b %errorlevel%

