@echo off
cd /d "%~dp0"
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 /WX /O2 /MT /I"minhook\include" range_test.cpp hook.obj buffer.obj trampoline.obj hde64.obj /Fe:range_new.exe
if errorlevel 1 exit /b 1
range_new.exe
exit /b %errorlevel%

