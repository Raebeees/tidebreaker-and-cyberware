@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 /WX /O2 /MT /Iminhook\include trampoline_test.cpp hook.obj buffer.obj trampoline.obj hde64.obj /Fe:trampoline_test.exe
if errorlevel 1 exit /b 1
trampoline_test.exe
exit /b %errorlevel%
