@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 /WX /O2 /MT manifest_compat_test.cpp /Fe:manifest_compat_test.exe
if errorlevel 1 exit /b 1
manifest_compat_test.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 /WX /O2 /MT launch_test.cpp /Fe:launch_test.exe
if errorlevel 1 exit /b 1
launch_test.exe
exit /b %errorlevel%

