@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 /WX /O2 /MT crow_test.cpp /Fe:crow_test.exe
if errorlevel 1 exit /b 1
crow_test.exe
exit /b %errorlevel%
