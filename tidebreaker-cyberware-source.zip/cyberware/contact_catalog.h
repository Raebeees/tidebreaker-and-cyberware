#pragma once
#include <cstddef>
namespace contact {
inline constexpr unsigned BodyBase=32, HeadBase=247;
inline constexpr const char* Styles0[]={"Female"};
inline constexpr const char* Styles1[]={"Female"};
inline constexpr const char* Styles2[]={"Female"};
inline constexpr const char* Styles3[]={"Female"};
inline constexpr const char* Styles4[]={"Flat","LessDepth","MoreDepth"};
inline constexpr const char* Styles5[]={"EARLESS_DOWN","EARLESS_FLAT","EARLESS_UP","FULL_DOWN","FULL_FLAT","FULL_UP"};
inline constexpr const char* Styles6[]={"ORIGINAL","PLATE_DOWN","PLATE_FLAT","PLATE_UP","SMOOTH"};
inline constexpr const char* const* Styles[]={Styles0,Styles1,Styles2,Styles3,Styles4,Styles5,Styles6};
inline constexpr unsigned StyleCounts[]={1,1,1,1,3,6,5};
inline constexpr unsigned Defaults[]={0,0,0,0,0,1,0};
}
