#pragma once
#include <windows.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <string>
#include <vector>
#include "art_profile.h"
#include "attachment_policy.h"
#include "contact_catalog.h"

namespace contact {
inline std::filesystem::path dataRoot;
inline std::filesystem::path ModRoot=L"C:/Modding/dmm/mods/Cyberware Plate Mesh Diagnostic";
inline constexpr unsigned Width=2048,Height=4096,Pixels=Width*Height;
inline bool body(unsigned value){return value==11||(value>=BodyBase&&value<BodyBase+3);}
inline bool head(unsigned value){return value==69||(value>=HeadBase&&value<HeadBase+3);}
inline bool readyFor(const cyberware::Selection& selection,const cyberware::Look& look){
    (void)selection;
    return look[0]==11&&look[1]==69;
}
inline std::string texture(unsigned region,unsigned bank){
    return "character/texture/codex_contact/"+std::string(region?"scalp":"face")+"_"+std::to_string(bank)+".dds";
}
inline size_t ddsBytes(){
    size_t total=128;
    for(unsigned w=Width,h=Height;;w=(std::max)(1u,w/2),h=(std::max)(1u,h/2)){
        total+=size_t(w)*h*4;if(w==1&&h==1)break;
    }
    return total;
}
inline std::array<uint32_t,32> header(){
    std::array<uint32_t,32> h{};
    h[0]=0x20534444;h[1]=124;h[2]=0x2100f;h[3]=Height;h[4]=Width;h[5]=Width*4;h[7]=13;
    h[19]=32;h[20]=0x41;h[22]=32;h[23]=255;h[24]=0xff00;h[25]=0xff0000;h[26]=0xff000000;h[27]=0x401008;
    return h;
}
inline bool generated(const std::string& virtualPath,const std::filesystem::path& file){
    bool ours=false;
    for(unsigned r=0;r<2;r++)for(unsigned b=0;b<3;b++)
        if(virtualPath==texture(r,b)&&!_wcsicmp((ModRoot/virtualPath).lexically_normal().c_str(),file.lexically_normal().c_str()))ours=true;
    if(!ours)return false;
    std::ifstream input(file,std::ios::binary|std::ios::ate);
    if(!input||input.tellg()!=std::streamoff(ddsBytes()))return false;
    std::array<uint32_t,32> h{};input.seekg(0);
    return bool(input.read(reinterpret_cast<char*>(h.data()),sizeof h))&&h==header();
}
struct Sample{uint32_t index;int16_t x,y;};
static_assert(sizeof(Sample)==8);
struct Layer{std::vector<Sample> samples;std::vector<uint32_t> coverage;};
inline bool load(const std::filesystem::path& path,Layer& layer){
    std::ifstream input(path,std::ios::binary|std::ios::ate);
    if(!input)return false;
    auto bytes=input.tellg();input.seekg(0);
    uint32_t h[5]{};
    if(!input.read(reinterpret_cast<char*>(h),sizeof h)||h[0]!=0x31544353||h[1]!=Width||h[2]!=Height||h[3]>Pixels||h[4]>Pixels)return false;
    if(bytes!=std::streamoff(sizeof h+size_t(h[3])*8+size_t(h[4])*4))return false;
    layer.samples.resize(h[3]);layer.coverage.resize(h[4]);
    if(h[3]&&!input.read(reinterpret_cast<char*>(layer.samples.data()),h[3]*8))return false;
    if(h[4]&&!input.read(reinterpret_cast<char*>(layer.coverage.data()),h[4]*4))return false;
    for(auto s:layer.samples)if(s.index>=Pixels||s.x==-32768||s.y==-32768)return false;
    for(auto p:layer.coverage)if(p>=Pixels)return false;
    return true;
}
inline std::array<float,3> normal(float x,float y){
    float z=std::sqrt((std::max)(0.f,1-x*x-y*y));
    float length=std::sqrt(x*x+y*y+z*z);
    return {x/length,y/length,z/length};
}
inline unsigned char pack(float value){return static_cast<unsigned char>(std::clamp(std::lround((value*.5f+.5f)*255),0l,255l));}
inline void apply(unsigned char* pixel,Sample sample){
    auto base=normal(pixel[0]/127.5f-1,pixel[1]/127.5f-1);
    auto detail=normal(sample.x/32767.f,sample.y/32767.f);
    base[2]+=1;detail[0]*=-1;detail[1]*=-1;
    float factor=(base[0]*detail[0]+base[1]*detail[1]+base[2]*detail[2])/base[2];
    std::array<float,3> result{};
    float length=0;
    for(int i=0;i<3;i++){result[i]=base[i]*factor-detail[i];length+=result[i]*result[i];}
    length=std::sqrt(length);
    for(int i=0;i<3;i++)pixel[i]=pack(result[i]/length);
    pixel[3]=255;
}
inline bool writeDDS(const std::filesystem::path& path,std::vector<unsigned char> pixels){
    auto temp=path;temp+=L".contact-stage";
    std::ofstream output(temp,std::ios::binary|std::ios::trunc);
    if(!output)return false;
    auto h=header();output.write(reinterpret_cast<const char*>(h.data()),sizeof h);
    for(unsigned w=Width,high=Height;;){
        output.write(reinterpret_cast<const char*>(pixels.data()),pixels.size());
        if(w==1&&high==1)break;
        unsigned nw=(std::max)(1u,w/2),nh=(std::max)(1u,high/2);
        std::vector<unsigned char> next(size_t(nw)*nh*4);
        for(unsigned y=0;y<nh;y++)for(unsigned x=0;x<nw;x++){
            float sx=0,sy=0,sz=0;
            for(unsigned dy=0;dy<2;dy++)for(unsigned dx=0;dx<2;dx++){
                size_t at=(size_t((std::min)(high-1,y*2+dy))*w+(std::min)(w-1,x*2+dx))*4;
                auto n=normal(pixels[at]/127.5f-1,pixels[at+1]/127.5f-1);
                sx+=n[0];sy+=n[1];sz+=n[2];
            }
            float len=std::sqrt(sx*sx+sy*sy+sz*sz);size_t at=(size_t(y)*nw+x)*4;
            next[at]=pack(sx/len);next[at+1]=pack(sy/len);next[at+2]=pack(sz/len);next[at+3]=255;
        }
        pixels.swap(next);w=nw;high=nh;
    }
    output.close();
    if(!output){std::filesystem::remove(temp);return false;}
    if(!MoveFileExW(temp.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)){std::filesystem::remove(temp);return false;}
    return true;
}
inline bool prepare(const cyberware::Selection& selection,const cyberware::Look& current,cyberware::Look& target){
    if(!cyberware::Valid(selection))return false;
    // Recover only the aliases introduced by this experiment. Preserve native
    // selections; no normal-map generation or material substitution here.
    if(current[0]>=BodyBase&&current[0]<BodyBase+3)target[0]=11;
    if(current[1]>=HeadBase&&current[1]<HeadBase+3)target[1]=69;
    return true;
}
}

