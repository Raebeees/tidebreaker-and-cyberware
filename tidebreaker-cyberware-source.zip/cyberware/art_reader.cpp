#include "art_profile.h"
#include "jaw_surface.h"
#include "log.h"
#include "skin_trace.h"
#include <atomic>
#include "addresses.h"
#include "MinHook.h"
#include <cstring>
#include <cstdio>
#include <cstdint>
namespace cyberware {
namespace {
using Load=uintptr_t(__fastcall*)(void*,void*,void*,uintptr_t,void*);
Load original=nullptr;
uintptr_t field(uintptr_t p,int off){return *reinterpret_cast<uintptr_t*>(p+off);}
const char* replacement(const char* path){
    static constexpr char prefix[]="character/texture/codex_cyberware_v1/cw_0";
    if(strncmp(path,prefix,sizeof(prefix)-1))return nullptr;
    auto p=path+sizeof(prefix)-1;
    if(*p<'1'||*p>'8'||p[1]!='_')return nullptr;
    unsigned design=*p-'1';p+=2;
    static constexpr const char* finishes[]={"art0_","art1_","art2_","art3_","art4_","art5_"};
    for(unsigned bank=0;bank<6;bank++){
        size_t len=strlen(finishes[bank]);
        if(strncmp(p,finishes[bank],len))continue;
        unsigned v=materialBanks[design][bank].load();
        if(!v)return nullptr;
        auto profile=ArtProfile::unpack(v);if(!profile.valid(design))return nullptr;
        auto &list=ArtLists[design];
        if(!strcmp(p+len,"base.dds")){recordMaterialRead(design,bank,v,1);return profile.custom?path:list.colors[profile.color].path;}
        if(!strcmp(p+len,"normal.dds")){recordMaterialRead(design,bank,v,2);return list.normals[profile.normal].path;}
        if(!strcmp(p+len,"surface.dds")){recordMaterialRead(design,bank,v,4);return profile.custom?path:design==6?JawSurfacePaths[profile.metal*7+profile.rough]:SurfacePaths[profile.metal*3+profile.rough];}
    }
    return nullptr;
}
void patch(void* rootOut){
    __try{
        auto root=rootOut?*static_cast<uintptr_t*>(rootOut):0;if(!root)return;
        bool isModel=false;
        for(auto top:{root,field(root,0x38)})for(auto e=top;e;e=field(e,0x60)){
            auto name=reinterpret_cast<const char*>(field(e,0));
            if(name&&!strncmp(name,"SkinnedMeshProperty",19)){isModel=true;break;}
        }
        if(!isModel)return;
        uintptr_t stack[64]={root};unsigned depth=1,count=0;
        while(depth&&count<200000){
            for(auto e=stack[--depth];e&&count++<200000;e=field(e,0x60)){
                for(auto a=field(e,0x48);a;a=field(a,0x38)){
                    auto n=reinterpret_cast<const char*>(field(a,0));auto v=reinterpret_cast<const char*>(field(a,8));
                    if(n&&v&&!strcmp(n,"_path")){
                        static std::atomic<unsigned> targetReads{0};
                        if(!_stricmp(v,"character/texture/PHW_00_Head_Base_Youth_0010_n.dds")||
                           !_stricmp(v,"character/texture/PHW_00_Head_Base_Youth_0011_n.dds")){
                            unsigned count=targetReads.fetch_add(1);
                            if(count<128)Log("cyberware: face normal read unchanged; epoch=%u playerRebuild=%u thread=%lu path=%s",
                                skin_trace::epoch.load(),unsigned(skin_trace::playerRebuild),GetCurrentThreadId(),v);
                        }
                        if(auto replace=replacement(v))*reinterpret_cast<const char**>(a+8)=replace;
                    }
                }
                auto child=field(e,0x38);if(child&&depth<64)stack[depth++]=child;
            }
        }
    }__except(EXCEPTION_EXECUTE_HANDLER){}
}
uintptr_t __fastcall readModel(void* a,void* root,void* file,uintptr_t flags,void* e){
    auto result=original(a,root,file,flags,e);patch(root);return result;
}
}
bool InstallMaterialReader(){
    // Chain the verified Character Creator detour so both readers see the parsed tree.
    __try {
        auto entry=reinterpret_cast<unsigned char*>(AddressOf(ADDR_LOADXML));
        if(!entry||entry[0]!=0xe9)return false;
        auto relay=entry+5+*reinterpret_cast<int32_t*>(entry+1);
        if(relay[0]!=0xff||relay[1]!=0x25)return false;
        auto target=*reinterpret_cast<void**>(relay+6+*reinterpret_cast<int32_t*>(relay+2));
        MEMORY_BASIC_INFORMATION mbi{};
        if(!VirtualQuery(target,&mbi,sizeof(mbi))||mbi.AllocationBase!=GetModuleHandleW(L"CharacterCreator.asi"))return false;
        auto init=MH_Initialize();
        if(init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED)return false;
        if(MH_CreateHook(target,reinterpret_cast<void*>(&readModel),reinterpret_cast<void**>(&original))!=MH_OK)return false;
        if(MH_EnableHook(target)!=MH_OK){MH_RemoveHook(target);return false;}
        artReady=true;return true;
    }__except(EXCEPTION_EXECUTE_HANDLER){return false;}
}
}





