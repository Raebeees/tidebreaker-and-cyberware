#pragma once
#include <array>
#include <cstdint>
#include "menu_catalog.h"
#include "native_catalog.h"
namespace cyberware {
enum class Finish : uint8_t { Black, Chrome, Gunmetal, Gold };
struct Selection {
    std::array<bool, DesignCount> enabled{};
    std::array<Finish, DesignCount> finishes{};
    bool operator==(const Selection& b) const { return enabled==b.enabled && finishes==b.finishes; }
    bool operator!=(const Selection& b) const { return !(*this==b); }
};
inline bool Valid(const Selection& s) {
    for (size_t i=0;i<DesignCount;i++) {
        if(i>=8&&s.enabled[i]&&!WaveAvailable[i-8])return false;
        if(i==7&&unsigned(s.finishes[i])>0&&unsigned(s.finishes[i])<4)return false;
        if (static_cast<unsigned>(s.finishes[i])>=FinishCounts[i]) return false;
        if(s.enabled[i]) for(size_t j=i+1;j<DesignCount;j++)
            if(s.enabled[j] && Conflicts[i][j]) return false;
    }
    if(s.enabled[5]&&s.enabled[6]&&unsigned(s.finishes[5])>=7)return false;
    return true;
}
inline uint32_t OccupiedRegions(const Selection& s) {
    uint32_t mask=0;
    for(size_t i=0;i<DesignCount;i++) if(s.enabled[i])mask|=DesignRegions[i];
    return mask;
}
// Region occupancy is navigation metadata. Feature coverage (brows/hair) must
// be supplied by the geometry coverage adapter, never inferred from this mask.
struct CombinedBackend {
    virtual ~CombinedBackend()=default;
    virtual bool ready() const=0;
    virtual bool apply(const Selection&)=0;
    virtual bool confirmed(const Selection&) const=0;
};
struct CombinedSession {
    Selection opened{},preview{},saved{};
    unsigned edits=0;
    bool visible=false,canceling=false;
    void open(const Selection& current) { opened=preview=current;visible=true;canceling=false; }
    bool choose(CombinedBackend& b,size_t design,bool enabled,Finish finish) {
        if(!visible||canceling||design>=DesignCount||!b.ready())return false;
        Selection next=preview;
        if(enabled)for(size_t i=0;i<DesignCount;++i)
            if(i!=design&&WaveHomes[i]==WaveHomes[design]&&DesignSlots[i]==DesignSlots[design])next.enabled[i]=false;
        next.enabled[design]=enabled;next.finishes[design]=finish;
        if(!Valid(next)||!b.apply(next))return false;
        preview=next;++edits;return true;
    }
    bool cancel(CombinedBackend& b) {
        if(!visible)return false;
        if(!canceling&&preview!=opened) {
            if(!b.ready()||!b.apply(opened))return false;
            canceling=true;
        }
        if(canceling&&!b.confirmed(opened))return false;
        preview=opened;canceling=false;visible=false;return true;
    }
    bool commit(CombinedBackend& b) {
        if(!visible||canceling||!b.confirmed(preview))return false;
        saved=preview;visible=false;return true;
    }
};
}


