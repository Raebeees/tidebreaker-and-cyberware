#pragma once
#include <windows.h>
#include <algorithm>
#include <array>
#include <string>
#include "desktop_overlay.h"
#include "menu_state.h"
#include "material_picker.h"
#include "gallery_layout.h"
#include "spectrum_picker.h"
namespace cyberware {
class RegionMenu {
    size_t focus = 0;
    MaterialPicker picker;
    SpectrumPicker spectrum;
    bool rgbPage=false;
    bool body = true;
    bool frameFace=true;
    float faceX=.5f,faceY=.35f;
    D2D1_RECT_F liveBounds{};
    static constexpr auto& areaOf=WaveHomes;
    static constexpr auto& areas=WaveAreas;
    int area=0,hoverArea=-1,hoverDesign=-1;
    void selectArea(int a){
        area=a;hoverDesign=-1;body=false;feedback.clear();
        for(size_t i=0;i<DesignCount;i++)if(areaOf[i]==a){focus=i;break;}
        for(size_t i=0;i<DesignCount;i++)if(areaOf[i]==a&&session.preview.enabled[i]){focus=i;break;}
    }
    int guide=-1; std::array<ID2D1Bitmap*,4> references{};
    std::wstring feedback;
    std::wstring imageFolder;
    unsigned imageGeneration = ~0u;
    std::array<ID2D1Bitmap*, DesignCount> pictures{};
    int conflict(size_t design) const {
        for (size_t other=0; other<DesignCount; ++other)
            if (session.preview.enabled[other] && (areaOf[other]!=areaOf[design] || DesignSlots[other]!=DesignSlots[design]) && Conflicts[design][other]) return static_cast<int>(other);
        if(design==6&&session.preview.enabled[5]&&unsigned(session.preview.finishes[5])>=7)return 5;
        if(design==5&&session.preview.enabled[6]&&unsigned(session.preview.finishes[5])>=7)return 6;
        return -1;
    }
    void loadPictures(unsigned generation) {
        if (imageGeneration == generation) return;
        for (size_t i=0; i<DesignCount; ++i) {
            if (WaveHomes[i]<0) continue;
            if (pictures[i]) pictures[i]->Release();
            auto file=imageFolder+L"\\"+std::to_wstring(i+1)+L".png";
            pictures[i]=OverlayLoadImage(file.c_str());
        }
        for(unsigned i=0;i<4;i++){
            if(references[i])references[i]->Release();
            auto path=imageFolder+L"\\guide"+std::to_wstring(i+1)+(i==3?L".jpg":L".png");
            references[i]=OverlayLoadImage(path.c_str());
        }
        imageGeneration=generation;
    }
public:
    CombinedSession session;
    GalleryLayout layout;
    void begin(const Selection& current){body=true;hoverArea=-1;layout.drag=GalleryLayout::None;tilePressed=false;picker.open=false;guide=-1;feedback.clear();session.open(current);}
    bool tilePressed=false;
    bool mouseCommitted=false;
    std::wstring saveStatus;
    D2D1_RECT_F launcher() const {return D2D1::RectF(layout.width-140,12,layout.width-12,46);}
    struct Button {float x,y,w; int action; const wchar_t* text;};
    template<class Visit> void controls(Visit visit) const {
        if(guide>=0){
            visit(Button{16,514,150,'0',L"Overview"});
            visit(Button{805,514,140,VK_ESCAPE,L"Back"});
            return;
        }
        if(picker.open){
            visit(Button{805,514,140,VK_ESCAPE,L"Back"});
            return;
        }
        if(!body)visit(Button{805,5,178,'B',L"Body areas"});
        if(!body&&focus<8){
            for(unsigned i=0;i<(focus==7?1u:4u);++i)
                visit(Button{16.f+118*i,435,112,VK_F1+int(i),FinishNames[i]});
            if(focus<7)visit(Button{502,435,190,'M',L"Material presets"});
            visit(Button{699,435,230,'T',L"RGB / surface"});
        }
        if(!body){
            if(!session.preview.enabled[focus])visit(Button{16,514,120,VK_RETURN,L"Equip"});
            if(session.preview.enabled[focus])visit(Button{16,514,120,VK_SPACE,L"Remove"});
        }
        if(body)visit(Button{254,514,160,VK_RETURN,L"Done"});
        visit(Button{430,514,195,'G',L"Picture guide"});
        if(body && !(session.preview==session.opened))visit(Button{641,514,215,'U',L"Undo session edits"});
    }
    static unsigned swatch(const std::wstring& name){
        static constexpr struct {const wchar_t* name;unsigned rgb;} palette[]={
            {L"Black",0x242424},{L"Carbon",0x383838},{L"Iron",0x626262},{L"Metal",0x777a80},{L"Silver",0xc0c0c0},{L"Platinum",0xe8e7e4},
            {L"Red",0xb00000},{L"Bronze",0xc88335},{L"Copper",0xb36b18},{L"Gold",0xffd315},{L"White gold",0xffedb1},
            {L"Rose gold",0xffdcba},{L"Chrome",0xd9e2ec},{L"White",0xffffff},{L"Translucent black",0x474747},{L"Translucent white",0xdedede},{L"Translucent flesh",0xb1a193}
        };
        for(const auto& p:palette)if(name==p.name)return p.rgb;
        return 0x888888;
    }
    void chooseRgb(){
        if(!picker.value.custom){
            auto rgb=swatch(ArtLists[focus].colors[picker.value.color].name);
            spectrum.finish={int(rgb>>16),int((rgb>>8)&255),int(rgb&255),100,picker.value.metal<=2?picker.value.metal*50:50,picker.value.rough<=2?picker.value.rough*50:50};
        }
        rgbPage=picker.value.custom=true;spectrum.drag=-1;
    }
    bool pointer(UINT msg,float u,float v,CombinedBackend& backend){
        if(tilePressed){if(msg!=WM_MOUSEMOVE)tilePressed=false;return true;}
        if(layout.width<=0||layout.drag!=GalleryLayout::None)return layout.pointer(msg,u,v);
        float x=(u*layout.width-layout.left())/layout.scale(),y=(v*layout.height-layout.top())/layout.scale();
        if(msg==WM_MOUSEMOVE)hoverDesign=(!body&&!picker.open&&guide<0)?GalleryHit(area,x,y):-1;
        if(guide<0&&!picker.open&&body){
            if(msg==WM_LBUTTONDOWN&&u*layout.width>=liveBounds.left&&u*layout.width<liveBounds.right&&v*layout.height>=liveBounds.top&&v*layout.height<liveBounds.bottom){
                if(frameFace){
                    faceX=(u*layout.width-liveBounds.left)/(liveBounds.right-liveBounds.left);
                    faceY=(v*layout.height-liveBounds.top)/(liveBounds.bottom-liveBounds.top);
                }
                frameFace=!frameFace;tilePressed=true;return true;
            }
            int row=BodyHit(x,y);
            if(msg==WM_MOUSEMOVE)hoverArea=row;
            if(msg==WM_LBUTTONDOWN&&row>=0){selectArea(row);tilePressed=true;return true;}
        }
        if(msg==WM_LBUTTONDOWN){
            int action=0;
            controls([&](Button b){if(x>=b.x && x<b.x+b.w && y>=b.y && y<b.y+34)action=b.action;});
            if(!action && guide>=0 && !guide && x>=16 && x<983 && y>=52 && y<485)
                action='1'+int((x-16)/490)+2*int((y-52)/225);
            if(action){
                tilePressed=true;
                key(action,backend);
                mouseCommitted=action==VK_RETURN&&!session.visible;
                return true;
            }
        }
        if(guide>=0)return layout.pointer(msg,u,v);
        if(picker.open){
            if(rgbPage&&spectrum.pointer(msg,x,y))return true;
            if(msg==WM_LBUTTONDOWN&&y>=44&&y<=76&&x>=670&&x<=976){
                tilePressed=true;
                if(x>=840){key(VK_RETURN,backend);return true;}
                if(!rgbPage)chooseRgb();else if(focus<7){rgbPage=picker.value.custom=false;}
                return true;
            }
            if(msg==WM_LBUTTONDOWN&&!rgbPage){
                float top=77;
                for(unsigned g=0;g<5;g++){
                    auto names=picker.names(g);
                    for(unsigned i=0;i<names.size();i++){
                        float left=152+(i%5)*166,cy=top+(i/5)*31;
                        if(x>=left&&x<=left+161&&y>=cy&&y<=cy+28){
                            picker.section=g;picker.select(i);
                            if(g==1||g>=3)picker.value.custom=false;
                            tilePressed=true;return true;
                        }
                    }
                    top+=float((names.size()+4)/5)*31+12;
                }
            }
        }else if(!body&&msg==WM_LBUTTONDOWN&&x>=18&&x<978&&y>=75&&y<357){
            int choice=GalleryHit(area,x,y);
            if(choice>=0){focus=size_t(choice);feedback.clear();tilePressed=true;return true;}
        }
        return layout.pointer(msg,u,v);
    }
    void setImageFolder(const std::wstring& folder) { imageFolder=folder; }
    bool key(int key, CombinedBackend& backend) {
        if (!session.visible) return false;
        if(layout.keyboard(key))return true;
        if(guide>=0){
            if(key==VK_ESCAPE||key=='G')guide=-1;
            else if(key>='1'&&key<='4')guide=key-'0';
            else if(key=='0')guide=0;
            return true;
        }
        if((!picker.open&&key=='G')||key==VK_OEM_2){guide=0;return true;}
        if(picker.open){
            if(key=='T'&&focus<7){if(!rgbPage)chooseRgb();else{rgbPage=picker.value.custom=false;}return true;}
            if(rgbPage&&spectrum.key(key))return true;
            if(rgbPage&&key==VK_ESCAPE){if(focus==7)picker.open=false;rgbPage=false;spectrum.drag=-1;return true;}
            if(key==VK_ESCAPE){picker.open=false;feedback.clear();return true;}
            if(key>=VK_F1&&key<=VK_F5){picker.section=key-VK_F1;return true;}
            if(!rgbPage&&key>='A'&&key<='P'){picker.select(key-'A');if(picker.section==1||picker.section>=3)picker.value.custom=false;return true;}
            if(key==VK_RETURN){
                if(!artReady){feedback=L"Game material reader unavailable";return true;}
                if(focus==5&&picker.styles[picker.style]==L"Full"&&session.preview.enabled[6]){feedback=L"Full scalp overlaps the jaw shell. Choose Earless or remove the jaw.";return true;}
                if(conflict(focus)>=0&&!(focus==5&&picker.styles[picker.style]==L"Earless")){feedback=std::wstring(L"Remove ")+DesignNames[conflict(focus)];return true;}
                unsigned first=focus==5&&picker.styles[picker.style]==L"Full"?3:0;
                unsigned bank=first;
                auto occupied=[&](const Selection& s,unsigned b){return s.enabled[focus]&&unsigned(s.finishes[focus])==4+b;};
                while(occupied(session.opened,bank)||occupied(session.preview,bank))++bank;
                if(bank>=first+3||!picker.value.valid(unsigned(focus)))return true;
                auto priorColor=rgbBanks[focus][bank];
                if(picker.value.custom){
                    if(!writeFinish(unsigned(focus),bank,spectrum.finish)){feedback=L"Could not write the custom finish. Previous selection is active.";return true;}
                    rgbBanks[focus][bank]=spectrum.finish;
                }
                materialReads[focus][bank]=0;
                auto prior=materialBanks[focus][bank].exchange(picker.value.pack());
                if(!session.choose(backend,focus,true,static_cast<Finish>(4+bank))){
                    materialBanks[focus][bank]=prior;rgbBanks[focus][bank]=priorColor;
                    if(prior&&ArtProfile::unpack(prior).custom)writeFinish(unsigned(focus),bank,priorColor);
                    feedback=L"Waiting for the previous selection";return true;
                }
                feedback=std::wstring(L"Applied   ")+DesignNames[focus];return true;
            }
            return true;
        }
        if(!body&&focus<8&&(key=='M'||key=='T')){
            unsigned bank=unsigned(session.preview.finishes[focus]);picker.start(unsigned(focus),bank);
            rgbPage=picker.value.custom;spectrum.finish=bank>=4?rgbBanks[focus][bank-4]:RgbFinish{};
            if(!rgbPage&&(key=='T'||focus==7))chooseRgb();
            spectrum.drag=-1;feedback.clear();return true;
        }
        if(!body&&key==VK_RETURN){
            if(focus>=8&&!WaveAvailable[focus-8]){feedback=L"Fit under review";return true;}
            if(session.choose(backend,focus,true,session.preview.finishes[focus])){
                feedback=std::wstring(L"Applied   ")+DesignNames[focus];
            }else feedback=conflict(focus)>=0?std::wstring(L"Remove ")+DesignNames[conflict(focus)]+L" first":L"Waiting for the character";
            return true;
        }
        if(!body&&(key==VK_ESCAPE||key=='B')){body=true;feedback.clear();return true;}
        if(body && key=='U'){session.cancel(backend);return true;}
        if(body && (key==VK_ESCAPE||key==VK_RETURN)){session.saved=session.preview;session.visible=false;return true;}
        if (key==VK_RETURN) { if(!session.commit(backend)) feedback=L"Waiting for attachment and material readback"; return true; }
        if(body){if(key>='1'&&key<='9')selectArea(key-'1');return true;}
        if(key>='1'&&key<='9'){
            int ordinal=key-'1';
            for(size_t i=0;i<DesignCount;i++)if(areaOf[i]==area&&ordinal--==0){focus=i;feedback.clear();break;}
            return true;
        }
        if(key==VK_LEFT||key==VK_RIGHT||key==VK_UP||key==VK_DOWN){
            do{focus=(focus+(key==VK_LEFT||key==VK_UP?DesignCount-1:1))%DesignCount;}while(areaOf[focus]!=area);
            feedback.clear();return true;
        }
        if(focus>=8&&!WaveAvailable[focus-8]){feedback=L"Fit under review";return true;}
        bool enabled=session.preview.enabled[focus];
        auto finish=session.preview.finishes[focus];
        if (key==VK_SPACE) enabled=!enabled;
        else if (key>=VK_F1 && key<=VK_F4) {
            unsigned index=key-VK_F1;
            if((focus==7&&index>0)||index>=FinishCounts[focus]) { feedback=L"This finish is unavailable for this design"; return true; }
            finish=static_cast<Finish>(index);
        } else return false;
        int other=conflict(focus);
        if(enabled && other>=0) feedback=std::wstring(L"Remove ")+DesignNames[other]+L" to equip this design";
        else if(!session.choose(backend,focus,enabled,finish)) feedback=L"Waiting for the character or the previous selection";
        else feedback.clear();
        return true;
    }
    void draw(const OverlayDrawContext& ctx,const CombinedBackend& backend) {
        
        if(session.visible)loadPictures(ctx.generation);
        auto dc=ctx.dc;
        ID2D1SolidColorBrush* brush=nullptr;
        IDWriteTextFormat* font=nullptr;
        if(FAILED(dc->CreateSolidColorBrush(D2D1::ColorF(0xffffff),&brush))) return;
        if(FAILED(ctx.write->CreateTextFormat(L"Segoe UI",nullptr,DWRITE_FONT_WEIGHT_SEMI_BOLD,DWRITE_FONT_STYLE_NORMAL,DWRITE_FONT_STRETCH_NORMAL,16,L"en-US",&font))) { brush->Release(); return; }
        D2D1_MATRIX_3X2_F previous; dc->GetTransform(&previous);
        const auto viewport=dc->GetSize();
        layout.width=viewport.width;layout.height=viewport.height;const float scale=layout.scale();
        dc->SetTransform(D2D1::Matrix3x2F::Scale(scale,scale)*D2D1::Matrix3x2F::Translation(layout.left(),layout.top()));
        auto box=[&](float x,float y,float w,float h,unsigned rgb){brush->SetColor(D2D1::ColorF(rgb));dc->FillRectangle(D2D1::RectF(x,y,x+w,y+h),brush);};
        auto label=[&](const std::wstring& s,float x,float y,float w,float h,unsigned rgb){brush->SetColor(D2D1::ColorF(rgb));dc->DrawText(s.c_str(),static_cast<UINT32>(s.size()),font,D2D1::RectF(x,y,x+w,y+h),brush,D2D1_DRAW_TEXT_OPTIONS_CLIP);};
        auto panel=[&](float x,float y,float w,float h,float radius,unsigned color){
            brush->SetColor(D2D1::ColorF(color));
            dc->FillRoundedRectangle(D2D1::RoundedRect(D2D1::RectF(x,y,x+w,y+h),radius,radius),brush);
        };
        auto picture=[&](size_t id,float x,float y,float w,float h){
            if(!pictures[id])return;
            auto size=pictures[id]->GetSize();float k=(std::min)(w/size.width,h/size.height);
            x+=(w-size.width*k)/2;y+=(h-size.height*k)/2;
            dc->DrawBitmap(pictures[id],D2D1::RectF(x,y,x+size.width*k,y+size.height*k));
        };
        if(!session.visible){
            dc->SetTransform(D2D1::Matrix3x2F::Identity());
            auto r=launcher();
            box(r.left,r.top,r.right-r.left,r.bottom-r.top,0x22262c);
            label(L"Cyberware",r.left+16,r.top+5,110,27,0xf3d6a2);
            dc->SetTransform(previous);font->Release();brush->Release();return;
        }
        auto buttons=[&](){controls([&](Button b){
            bool primary=b.action==VK_RETURN;
            panel(b.x,b.y,b.w,34,7,primary?0x9be5ce:0x28343f);
            label(b.text,b.x+12,b.y+5,b.w-17,25,primary?0x102921:0xe5edf1);
        });};
        box(0,0,1000,556,0x10171d);
        box(0,0,1000,41,0x19242e);
        panel(18,12,16,16,4,0x9be5ce);box(24,15,4,10,0x1b4039);
        label(L"Cyberware",44,8,114,29,0xf3f7f8);
        label(guide>=0?L"/    Picture guide":picker.open?L"/    Finish studio":body?L"/    Loadout":std::wstring(L"/    ")+areas[area],158,8,575,29,0xacc0cb);
        box(0,505,1000,51,0x17212a);
        panel(972,533,12,3,1,0x738791);
        panel(977,539,7,3,1,0x738791);

        if(guide>=0){
            for(unsigned i=0;i<4;i++){
                if(!references[i]||(guide&&guide!=int(i+1)))continue;
                float w=guide?968.f:477.f,h=guide?445.f:208.f;
                float x=guide?16.f:16+(i%2)*490.f,y=guide?52.f:52+(i/2)*225.f;
                auto size=references[i]->GetSize();float fit=(std::min)(w/size.width,h/size.height);
                float dx=(w-size.width*fit)/2,dy=(h-size.height*fit)/2;
                dc->DrawBitmap(references[i],D2D1::RectF(x+dx,y+dy,x+w-dx,y+h-dy),1,D2D1_BITMAP_INTERPOLATION_MODE_LINEAR);
            }
            buttons();
            dc->SetTransform(previous);font->Release();brush->Release();return;
        }
        if(picker.open){
            box(670,44,162,31,0x343a42);label(rgbPage?(focus<7?L"T   Presets":L"Custom RGB"):L"T   Custom RGB",680,48,148,26,0xf3d6a2);
            box(840,44,136,31,0x405f56);label(L"Apply",849,48,124,26,0xf0f3f1);
            if(rgbPage){
                label(std::wstring(DesignNames[focus])+L"   /   Custom RGB",24,50,650,30,0xf3d6a2);
                for(int j=0;j<12;j++)for(int i=0;i<60;i++)
                    box(34+i*9.9f,100+j*15.42f,10.1f,15.6f,SpectrumPicker::spectrum(i/59.f,j/11.f));
                box(668,100,301,185,spectrum.finish.rgb());
                for(int i=0;i<6;i++){
                    float y=306+i*32.f;int val=spectrum.channel(i);
                    label(std::to_wstring(i+1)+L"  "+SpectrumPicker::labels[i],34,y,125,25,i==spectrum.row?0xffcf8a:0xd8dbe1);
                    float thumb=466.f*val/SpectrumPicker::limit(i);
                    panel(160,y+10,466,5,2,0x394754);panel(160,y+10,thumb,5,2,0x9be5ce);
                    brush->SetColor(D2D1::ColorF(0xeaf6f2));dc->FillEllipse(D2D1::Ellipse({160+thumb,y+12},6,6),brush);
                    label(std::to_wstring(val)+(i>=3?L"%":L""),640,y,80,25,0xffffff);
                }
                label(feedback,705,310,265,115,0xffca9a);
                label(L"Drag the spectrum or a slider to edit your finish",18,519,940,26,0xe4e5e8); buttons();
                dc->SetTransform(previous);font->Release();brush->Release();return;
            }
            label(std::wstring(DesignNames[focus])+L"   /   Source materials",18,43,950,24,0xf3d6a2);
            static constexpr const wchar_t* groups[]={L"Style",L"Color",L"Depth",L"Metalness",L"Roughness"};
            float y=77;
            for(unsigned g=0;g<5;g++){
                auto names=picker.names(g);
                label(std::wstring(L"F")+std::to_wstring(g+1)+L"  "+groups[g],18,y,125,26,g==picker.section?0xffcd79:0xbbbec6);
                for(unsigned i=0;i<names.size();i++){
                    float x=152+(i%5)*166,cy=y+(i/5)*31;
                    box(x,cy,161,28,picker.selected(g,i)?0x465e57:0x30353b);
                    if(g==1)box(x+143,cy+7,12,12,swatch(names[i]));
                    label(std::wstring(1,wchar_t(L'A'+i))+L"  "+(names[i].empty()?L"Original":names[i]),x+5,cy+2,154,26,0xf0f1ef);
                }
                y+=static_cast<float>((names.size()+4)/5)*31+12;
            }
            label(feedback,18,467,965,24,0xffc8a0);
            label(L"Pick a swatch or surface, then apply your finish",18,519,964,26,0xd5d7da); buttons();
            dc->SetTransform(previous);font->Release();brush->Release();return;
        }
        if(body){
            const auto count=std::count(session.preview.enabled.begin(),session.preview.enabled.end(),true);
            label(L"Body areas",20,53,170,29,0xf1f5f8);
            label(std::to_wstring(count)+L" equipped",224,55,180,26,0x9be5ce);
            for(int a=0;a<WaveAreaCount;a++){
                int worn=0;for(size_t i=0;i<DesignCount;++i)if(areaOf[i]==a&&session.preview.enabled[i])++worn;
                auto t=BodyTile(a);
                panel(t.x,t.y,t.w,t.h,8,hoverArea==a?0x334c50:worn?0x223a36:0x202c36);
                label(areas[a],t.x+13,t.y+3,t.w-24,24,0xf2f6f7);
                int n=AreaSize(a);
                label(worn?std::to_wstring(worn)+L" equipped":std::to_wstring(n)+(n==1?L" design":L" designs"),t.x+13,t.y+26,t.w-21,22,worn?0x9be5ce:0xa8b9c4);
            }
            panel(428,55,550,388,10,0x1b262f);
            label(!feedback.empty()?feedback:saveStatus,20,463,945,30,0x9be5ce);
            auto line=[&](float x,float y,float xx,float yy){brush->SetColor(D2D1::ColorF(0xa8b3bb));dc->DrawLine({x,y},{xx,yy},brush,3);};
            brush->SetColor(D2D1::ColorF(0xa8b3bb));dc->DrawEllipse(D2D1::Ellipse({483,108},18,24),brush,3);
            static constexpr float side[][2]={{8,131},{9,140},{35,150},{47,193},{56,235},{49,242},{35,208},{25,179},{20,209},{29,239},{24,294},{20,347},{28,356},{10,356},{7,297},{0,251}};
            for(int sign:{-1,1})for(int i=1;i<int(sizeof(side)/sizeof(side[0]));i++)
                line(483+sign*side[i-1][0],side[i-1][1],483+sign*side[i][0],side[i][1]);
            int a=hoverArea>=0?hoverArea:area;
            static constexpr float pins[][2]={{483,107},{490,114},{492,114},{474,114},{483,96},{475,88},{487,126},{498,103},{490,105},{483,135},{483,118},{532,235}};
            brush->SetColor(D2D1::ColorF(0xf2c47d));dc->FillEllipse(D2D1::Ellipse({pins[a][0],pins[a][1]},5,5),brush);
            size_t preview=DesignCount;for(size_t i=0;i<DesignCount;i++)if(areaOf[i]==a){if(preview==DesignCount)preview=i;if(session.preview.enabled[i]){preview=i;break;}}
            panel(558,109,403,242,8,0x111a21);
            liveBounds={};
            RECT dest{LONG(layout.left()+561*scale),LONG(layout.top()+112*scale),LONG(layout.left()+958*scale),LONG(layout.top()+348*scale)};
            bool live=a!=11&&ctx.portrait&&ctx.portrait(dest,frameFace,faceX,faceY,liveBounds);
            if(!live)picture(preview,561,112,397,236);
            label(areas[a],558,70,396,30,0x9be5ce);
            label(DesignNames[preview],558,369,402,28,0xf2f6f7);
            label(live?(frameFace?L"Click your face to zoom in":L"Live character   /   Click to reframe"):session.preview.enabled[preview]?L"Equipped on your character":L"Design preview",558,401,402,25,0xa8b9c4);
        }else{
            int col=0;
            label(L"Choose a design",18,44,700,28,0xc6b299);
            for(size_t i=0;i<DesignCount;i++)if(areaOf[i]==area){
                const auto tile=TileAt(area,col++);
                const bool available=i<8||WaveAvailable[i-8];
                box(tile.x,tile.y,tile.w,tile.h,i==focus?0x9be5ce:int(i)==hoverDesign?0x759ba8:session.preview.enabled[i]?0x569b87:0x34424d);
                box(tile.x+2,tile.y+2,tile.w-4,tile.h-4,0x22262c);
                const float footer=tile.h<90?21.f:45.f;
                if(pictures[i]){auto size=pictures[i]->GetSize();
                    float scale=(std::min)((tile.w-8)/size.width,(tile.h-footer-4)/size.height);
                    float x=tile.x+(tile.w-size.width*scale)/2;
                    dc->DrawBitmap(pictures[i],D2D1::RectF(x,tile.y+3,x+size.width*scale,tile.y+3+size.height*scale));}
                label(std::wstring(session.preview.enabled[i]?L"+ ":L"")+DesignNames[i],tile.x+5,tile.y+tile.h-footer,tile.w-10,22,0xf2f2f2);
                if(footer>21)label(!available?L"Fit under review":session.preview.enabled[i]?L"Equipped":conflict(i)>=0?L"Conflict":L"Available",tile.x+5,tile.y+tile.h-23,tile.w-10,22,0xc6b299);
            }
            if(focus<8)label(L"Finish",18,403,925,27,0xf2f6f7);
            else{
                const size_t id=hoverDesign>=0?size_t(hoverDesign):focus;
                panel(18,370,960,119,8,0x202c36);
                picture(id,28,377,252,104);
                label(DesignNames[id],298,381,650,27,0xf2f6f7);
                const int blocked=conflict(id);
                label(session.preview.enabled[id]?L"Equipped":blocked>=0?std::wstring(L"Conflicts with ")+DesignNames[blocked]:id==focus?L"Selected":L"Preview",298,414,650,25,0x9be5ce);
                label(feedback.empty()?saveStatus:feedback,298,449,655,28,0xa8b9c4);
            }
        }
        if(!body && focus<8){

            label(saveStatus,18,372,945,21,0x91dec4);
            int other=conflict(focus);
            label(!feedback.empty()?feedback:other>=0?std::wstring(L"Conflicts with ")+DesignNames[other]:!backend.ready()?L"Waiting for DamiElf":std::wstring(session.preview.enabled[focus]?L"Equipped   ":L"Selected   ")+DesignNames[focus],18,471,965,26,0xe7e7e7);
        }
        buttons();
        dc->SetTransform(previous);font->Release();brush->Release();
    }
};
}














