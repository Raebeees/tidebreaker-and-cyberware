#include "registration_guard.h"
int wmain(int argc,wchar_t** argv){
    if(argc!=3)return 2;
    bool expected=wcscmp(argv[2],L"pass")==0;
    return RegistrationVerifiedAt(argv[1])==expected?0:1;
}
