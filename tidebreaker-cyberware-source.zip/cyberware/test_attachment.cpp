#include <cassert>
#include "attachment_policy.h"
using namespace cyberware;
int main(){
    HairLease h;assert(h.target(true,82)==255&&h.owned&&h.original==82);
    assert(h.target(true,255)==255&&h.original==82);assert(h.target(false,255)==82&&!h.owned);
    // External hairstyle edits while hidden are retained on removal.
    h.target(true,82);assert(h.target(false,91)==91&&!h.owned);
    h.target(true,255);assert(h.target(false,255)==255);
    // Every valid combination and every finish round-trips to native slots.
    int valid=0,variants=0;
    for(unsigned mask=0;mask<128;mask++){
        Selection s;for(size_t i=0;i<7;i++)s.enabled[i]=(mask&(1u<<i))!=0;
        if(!Valid(s))continue;valid++;
        unsigned choices=1;for(size_t i=0;i<7;i++)if(s.enabled[i])choices*=FinishCounts[i];
        for(unsigned color=0;color<choices;color++){
            unsigned remainder=color;
            for(size_t i=0;i<7;i++)if(s.enabled[i]){s.finishes[i]=static_cast<Finish>(remainder%FinishCounts[i]);remainder/=FinishCounts[i];}
            if(!Valid(s)){assert(s.enabled[5]&&s.enabled[6]&&unsigned(s.finishes[5])>=7);continue;} variants++;
            Look look{};assert(Encode(s,look));Selection decoded;assert(Decode(look,decoded));
            for(size_t i=0;i<8;i++){assert(decoded.enabled[i]==s.enabled[i]);if(s.enabled[i])assert(decoded.finishes[i]==s.finishes[i]);}
            assert(look[6]==BrowOptions[mask]);
            for(unsigned d=0;d<5;d++)if(s.enabled[d]&&(s.enabled[5]||s.enabled[6])){
                unsigned mode=s.enabled[5]&&unsigned(s.finishes[5])>=7?4:unsigned(s.enabled[6])+2*unsigned(s.enabled[5]);
                assert(look[DesignSlots[d]]==CoveredBases[d]+7*(mode-1)+unsigned(s.finishes[d]));
                Selection stripped=s;stripped.enabled[5]=stripped.enabled[6]=false;Look restored{};
                assert(Encode(stripped,restored)&&restored[DesignSlots[d]]<CoveredBases[d]&&QueueSlot(DesignSlots[d],look,restored));
            }
        }
    }
    for(size_t i=8;i<DesignCount;++i){
        Selection s;s.enabled[i]=true;Look look{};
        assert(Encode(s,look)==WaveAvailable[i-8]);
        if(!WaveAvailable[i-8])continue;
        assert(look[DesignSlots[i]]==DesignBases[i]);Selection restored;
        assert(Decode(look,restored)&&restored==s);
        assert(Encode(Selection{},look)&&look[DesignSlots[i]]==0);
    }
    for(unsigned old=1;old<=6;++old){
        Look previous{};previous[12]=static_cast<uint8_t>(old);previous[13]=1;
        Selection restored;assert(Decode(previous,restored)&&restored.enabled[17]);
        assert(Encode(restored,previous)&&previous[12]==0&&previous[13]==1);
    }
    assert(valid==28);
    assert(variants>925);
    Selection legacy;legacy.enabled[7]=true;Look look{};assert(Encode(legacy,look));assert(look[4]==1&&look[6]==1);legacy.finishes[7]=Finish::Gold;assert(!Encode(legacy,look));
    for(unsigned bank=0;bank<3;bank++){
        legacy.finishes[7]=static_cast<Finish>(4+bank);assert(Encode(legacy,look));assert(look[4]==30+bank&&look[6]==1);
        Selection restored;assert(Decode(look,restored)&&restored==legacy);
    }
    Look from{},to{};from[0]=to[0]=11;from[1]=to[1]=69;from[2]=82;to[2]=255;
    Request q;q.begin(from,to,100);auto changed=from;changed[2]=91;assert(!q.consume(changed,101));
    q.begin(from,to,100);assert(!q.consume(from,1101));q.begin(from,to,100);assert(q.consume(from,101));assert(!q.consume(from,102));
    // DWORD wrap must not invalidate a fresh request or permit an old request.
    q.begin(from,to,0xfffffff0u);assert(q.consume(from,5));
    q.begin(from,to,100);changed=from;changed[1]=70;assert(!q.consume(changed,101));
    assert(QueueSlot(6,from,to));assert(!QueueSlot(7,from,to));
    from[2]=to[2]=255;to[8]=1;assert(QueueSlot(2,from,to)&&QueueSlot(6,from,to));
    from[8]=1;to[8]=2;assert(!QueueSlot(2,from,to)&&!QueueSlot(6,from,to));
}


