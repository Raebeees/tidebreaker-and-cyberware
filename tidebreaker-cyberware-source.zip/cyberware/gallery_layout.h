#pragma once
#include <algorithm>
#include <cmath>
#include <string>
#include <windows.h>

struct GalleryLayout {
    bool standalone=false;
    float width=0,height=0;
    float anchorX=1,anchorY=.5f,zoom=1;
    std::wstring file;
    enum Drag { None, Move, Resize } drag=None;
    float startX=0,startY=0,startLeft=0,startTop=0,startScale=1;
    float margin() const {return (std::min)({12.f,width*.02f,height*.02f});}
    float base() const {return (std::min)(width*.46f/1000,height*.53f/556);}
    float scale() const {return standalone?(std::min)(width/1000.f,height/556.f):base()*zoom;}
    float travelX() const {return width-2*margin()-1000*scale();}
    float travelY() const {return height-2*margin()-556*scale();}
    float left() const {if(standalone)return (width-1000*scale())/2;return margin()+anchorX*travelX();}
    float top() const {if(standalone)return (height-556*scale())/2;return margin()+anchorY*travelY();}
    void place(float x,float y){
        anchorX=std::clamp((x-margin())/(std::max)(1.f,travelX()),0.f,1.f);
        anchorY=std::clamp((y-margin())/(std::max)(1.f,travelY()),0.f,1.f);
    }
    void load(const std::wstring& path){
        file=path;wchar_t value[80];int x,y,z;
        GetPrivateProfileStringW(L"Gallery",L"Layout",L"",value,80,file.c_str());
        if(swscanf_s(value,L"%d,%d,%d",&x,&y,&z)==3){
            anchorX=std::clamp(x,0,1000)/1000.f;anchorY=std::clamp(y,0,1000)/1000.f;zoom=std::clamp(z,65,165)/100.f;
        }
    }
    void save() const {
        wchar_t value[80];swprintf_s(value,L"%ld,%ld,%ld",lroundf(anchorX*1000),lroundf(anchorY*1000),lroundf(zoom*100));
        WritePrivateProfileStringW(L"Gallery",L"Layout",value,file.c_str());
    }
    bool keyboard(int key){
        if(standalone||width<=0||height<=0)return false;
        switch(key){
        case VK_OEM_PLUS:case VK_ADD:zoom=std::clamp(zoom+.05f,.65f,1.65f);break;
        case VK_OEM_MINUS:case VK_SUBTRACT:zoom=std::clamp(zoom-.05f,.65f,1.65f);break;
        case VK_HOME:anchorX=1;anchorY=.5f;zoom=1;break;
        default:
            if(!(GetKeyState(VK_CONTROL)&0x8000)||key<VK_LEFT||key>VK_DOWN)return false;
            place(left()+width*.02f*((key==VK_RIGHT)-(key==VK_LEFT)),top()+height*.02f*((key==VK_DOWN)-(key==VK_UP)));
        }
        save();return true;
    }
    bool pointer(UINT msg,float u,float v){
        if(standalone||width<=0||height<=0)return false;
        float x=u*width,y=v*height;
        if(msg==WM_LBUTTONDOWN){
            float localX=(x-left())/scale(),localY=(y-top())/scale();
            if(localX<0||localX>1000||localY<0||localY>556)return false;
            if(localY<=40)drag=Move;
            else if(localX>=958&&localY>=514)drag=Resize;
            else return false;
            startLeft=left();startTop=top();startScale=scale();startX=x;startY=y;return true;
        }
        if(drag==None)return false;
        if(msg==WM_MOUSEMOVE||msg==WM_LBUTTONUP){
            if(drag==Move)place(startLeft+x-startX,startTop+y-startY);
            else{
                float ds=((x-startX)*1000+(y-startY)*556)/(1000.f*1000+556.f*556);
                zoom=std::clamp((startScale+ds)/base(),.65f,1.65f);place(startLeft,startTop);
            }
        }
        if(msg!=WM_MOUSEMOVE){drag=None;save();}
        return true;
    }
};
