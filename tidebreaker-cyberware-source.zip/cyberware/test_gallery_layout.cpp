#include "gallery_layout.h"
#include <cassert>
int wmain(int argc,wchar_t** argv){
    assert(argc==2);
    GalleryLayout layout;layout.load(argv[1]);
    for(auto w:{1280.f,1920.f,3440.f}){
        layout.width=w;layout.height=1080;layout.keyboard(VK_HOME);
        assert(layout.left()>w*.5f);
        float x=(layout.left()+20*layout.scale())/w,y=(layout.top()+12*layout.scale())/1080;
        assert(layout.pointer(WM_LBUTTONDOWN,x,y));
        assert(layout.pointer(WM_LBUTTONUP,-1,-1));
        assert(layout.left()==layout.margin()&&layout.top()==layout.margin());
        x=(layout.left()+984*layout.scale())/w;y=(layout.top()+538*layout.scale())/1080;
        assert(layout.pointer(WM_LBUTTONDOWN,x,y));layout.pointer(WM_LBUTTONUP,2,2);
        assert(layout.zoom==1.65f && layout.left()+1000*layout.scale()<=w);
        for(int i=0;i<30;i++)layout.keyboard(VK_SUBTRACT);
        GalleryLayout restored;restored.load(argv[1]);assert(restored.zoom==.65f&&restored.anchorX==layout.anchorX);
    }
}
