#pragma once
#include "rgb_finish.h"
#include <algorithm>
#include <cmath>
namespace cyberware {
struct SpectrumPicker {
    RgbFinish finish;
    int row=0,drag=-1;
    static constexpr const wchar_t* labels[]={L"Red",L"Green",L"Blue",L"Brightness",L"Metalness",L"Roughness"};
    int& channel(int i){switch(i){case 0:return finish.r;case 1:return finish.g;case 2:return finish.b;case 3:return finish.brightness;case 4:return finish.metal;default:return finish.rough;}}
    static int limit(int i){return i<3?255:100;}
    static unsigned spectrum(float hue,float sat){
        float h=hue*6;int sector=int(h)%6;float f=h-int(h),p=1-sat,q=1-f*sat,t=1-(1-f)*sat;
        float rgb[6][3]={{1,t,p},{q,1,p},{p,1,t},{p,q,1},{t,p,1},{1,p,q}};
        auto v=rgb[sector];return unsigned(lroundf(v[0]*255))<<16|unsigned(lroundf(v[1]*255))<<8|unsigned(lroundf(v[2]*255));
    }
    bool key(int k){
        if(k>='1'&&k<='6'){row=k-'1';return true;}
        if(k==VK_UP||k==VK_DOWN){row=(row+(k==VK_DOWN?1:5))%6;return true;}
        if(k!=VK_LEFT&&k!=VK_RIGHT)return false;
        int step=(GetKeyState(VK_SHIFT)&0x8000)?10:1;
        channel(row)=std::clamp(channel(row)+(k==VK_LEFT?-step:step),0,limit(row));return true;
    }
    bool pointer(UINT msg,float x,float y){
        if(msg==WM_LBUTTONDOWN){
            if(x>=34&&x<=628&&y>=100&&y<=285)drag=6;
            else if(x>=160&&x<=626&&y>=306&&y<498){row=drag=int((y-306)/32);}
            else return false;
        }
        if(drag<0)return false;
        if(msg==WM_MOUSEMOVE||msg==WM_LBUTTONDOWN||msg==WM_LBUTTONUP){
            if(drag==6){auto rgb=spectrum(std::clamp((x-34)/594.f,0.f,1.f),std::clamp((y-100)/185.f,0.f,1.f));finish.r=rgb>>16;finish.g=(rgb>>8)&255;finish.b=rgb&255;}
            else channel(drag)=int(lroundf(std::clamp((x-160)/466.f,0.f,1.f)*limit(drag)));
        }
        if(msg!=WM_MOUSEMOVE&&msg!=WM_LBUTTONDOWN)drag=-1;
        return true;
    }
};
}
