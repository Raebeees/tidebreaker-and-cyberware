@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cd /d "%~dp0"
if not exist build mkdir build
pushd build
set "CCSRC=%~dp0dependencies\CharacterCreator"
cl /nologo /std:c++17 /EHsc /W4 /DUNICODE /D_UNICODE /I"%CCSRC%" ..\test_desktop.cpp /Fetest_desktop.exe /link d2d1.lib dwrite.lib windowscodecs.lib user32.lib gdi32.lib ole32.lib
if errorlevel 1 exit /b 1
dumpbin /imports CyberwareCompanion.asi >desktop-imports.txt
exit /b %errorlevel%
