#include "contact_runtime.h"
#include <cassert>
int main(){
 cyberware::Selection gold;gold.enabled[0]=true;gold.finishes[0]=cyberware::Finish::Gold;
 cyberware::Look native{},target{};native[0]=11;native[1]=69;native[3]=42;target=native;
 assert(contact::prepare(gold,native,target));assert(target==native);
 auto alias=native;alias[0]=contact::BodyBase+2;alias[1]=contact::HeadBase+2;target=alias;
 assert(contact::prepare(gold,alias,target));assert(target==native);
 cyberware::Selection off;target=native;assert(contact::prepare(off,native,target));assert(target==native);
 auto other=native;other[0]=12;other[1]=70;target=other;
 assert(contact::prepare(gold,other,target));assert(target==other);
}
