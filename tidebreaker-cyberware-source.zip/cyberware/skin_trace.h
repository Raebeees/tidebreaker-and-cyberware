#pragma once
#include <atomic>
namespace skin_trace {
inline std::atomic<unsigned> epoch{0};
inline thread_local bool playerRebuild=false;
struct RebuildScope {
 bool previous;
 RebuildScope():previous(playerRebuild){playerRebuild=true;++epoch;}
 ~RebuildScope(){playerRebuild=previous;}
};
}
