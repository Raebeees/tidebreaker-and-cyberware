#include "desktop_overlay.cpp"
#include <cassert>
static const wchar_t* imageFile;
static int clicks=0,draws=0;
bool GalleryPointer(HWND,UINT msg,LPARAM){if(msg==WM_LBUTTONDOWN)++clicks;return true;}
extern "C" void WINAPI OpenCyberwareGallery(HWND){OverlaySetVisible(true);}
void Log(const char*,...){}
static void drawTest(const OverlayDrawContext& ctx){
    D2D1_RECT_F bounds{};assert(ctx.portrait&&ctx.portrait({200,100,600,350},true,.5f,.5f,bounds));assert(bounds.left>=200 && bounds.right<=600 && bounds.bottom>bounds.top);assert(ctx.portrait({200,100,600,350},false,.7f,.4f,bounds)&&bounds.left==200&&bounds.bottom==350);auto picture=OverlayLoadImage(imageFile);assert(picture);
    ctx.dc->DrawBitmap(picture,D2D1::RectF(0,0,120,100));picture->Release();++draws;
}
static void keyTest(int k){if(k==VK_ESCAPE)OverlaySetVisible(false);}
int wmain(int argc,wchar_t** argv){
    assert(argc==2&&OverlayInit());imageFile=argv[1];
    OverlaySetCallbacks(drawTest,keyTest);
    HWND owner=CreateWindowW(L"STATIC",L"Gallery test host",WS_POPUP,12,12,900,600,nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
    assert(owner);OpenCyberwareGallery(owner);OverlayFrame(owner);
    assert(IsWindowVisible(editor)&&GetWindow(editor,GW_OWNER)==owner);
    UpdateWindow(editor);assert(draws>0);
    auto screen=GetDC(editor);auto output=CreateCompatibleDC(screen);auto bitmap=CreateCompatibleBitmap(screen,800,500);
    auto old=SelectObject(output,bitmap);
    assert(SendMessageW(editor,WM_PRINTCLIENT,(WPARAM)output,PRF_CLIENT));GdiFlush();
    assert(GetPixel(output,60,50)!=CLR_INVALID&&GetPixel(output,60,50)!=GetPixel(output,200,50));
    SelectObject(output,old);DeleteObject(bitmap);DeleteDC(output);ReleaseDC(editor,screen);
    SendMessageW(editor,WM_LBUTTONDOWN,MK_LBUTTON,MAKELPARAM(40,50));SendMessageW(editor,WM_LBUTTONUP,0,MAKELPARAM(40,50));assert(clicks==1);
    SendMessageW(editor,WM_KEYDOWN,VK_ESCAPE,0);OverlayFrame(editor);assert(!IsWindowVisible(editor));
}

