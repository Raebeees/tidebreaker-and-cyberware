#pragma once
#include <d2d1.h>
#include <dwrite.h>
struct OverlayDrawContext { ID2D1RenderTarget* dc; IDWriteFactory* write; float width,height; unsigned generation; bool (*portrait)(RECT,bool,float,float,D2D1_RECT_F&)=nullptr; };
void OverlaySetCallbacks(void(*draw)(const OverlayDrawContext&),void(*key)(int));
bool OverlayInit();
void OverlayFrame(HWND foreground);
void OverlaySetVisible(bool);
void OverlaySetDrawing(bool);
ID2D1Bitmap* OverlayLoadImage(const wchar_t*);
