#pragma once
#include <array>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <string>
#include <windows.h>

namespace cyberware {
struct RgbFinish {
    int r=255,g=180,b=50,brightness=100,metal=50,rough=50;
    unsigned rgb()const{
        auto lit=[&](int c){return unsigned((c*brightness+50)/100);};
        return lit(r)<<16|lit(g)<<8|lit(b);
    }
    bool valid()const{return r>=0&&r<=255&&g>=0&&g<=255&&b>=0&&b<=255&&brightness>=0&&brightness<=100&&metal>=0&&metal<=100&&rough>=0&&rough<=100;}
};
using SwatchDDS=std::array<unsigned char,128+4*(16+4+1)>;
inline SwatchDDS swatchDDS(unsigned r,unsigned g,unsigned b){
    // Legacy RGBA8, with 4x4, 2x2 and 1x1 mip levels.
    std::array<uint32_t,32> h{};
    h[0]=0x20534444;h[1]=124;h[2]=0x2100f;h[3]=h[4]=4;h[5]=16;h[7]=3;
    h[19]=32;h[20]=0x41;h[22]=32;h[23]=255;h[24]=0xff00;h[25]=0xff0000;h[26]=0xff000000;h[27]=0x401008;
    SwatchDDS bytes{};memcpy(bytes.data(),h.data(),sizeof h);
    for(size_t i=128;i<bytes.size();i+=4){bytes[i]=static_cast<unsigned char>(r);bytes[i+1]=static_cast<unsigned char>(g);bytes[i+2]=static_cast<unsigned char>(b);bytes[i+3]=255;}
    return bytes;
}
inline std::string marker(unsigned d,unsigned bank,const char* type){
    return "character/texture/codex_cyberware_v1/cw_0"+std::to_string(d+1)+"_art"+std::to_string(bank)+"_"+type+".dds";
}
inline bool isGeneratedMap(const std::string& name,const std::filesystem::path& file){
    bool allowed=false,surface=false;
    for(unsigned d=0;d<8&&!allowed;d++)for(unsigned b=0;b<(d==5?6u:3u);b++){
        if(name==marker(d,b,"base")){allowed=true;break;}
        if(name==marker(d,b,"surface")){surface=allowed=true;break;}
    }
    if(!allowed)return false;
    std::ifstream input(file,std::ios::binary|std::ios::ate);
    SwatchDDS bytes{};if(!input||input.tellg()!=std::streamoff(bytes.size()))return false;
    input.seekg(0);input.read(reinterpret_cast<char*>(bytes.data()),bytes.size());
    return input.good()&&(!surface||bytes[128]==0)&&bytes==swatchDDS(bytes[128],bytes[129],bytes[130]);
}
inline std::filesystem::path editableMap[8][6][2];
inline bool writeMap(const std::filesystem::path& path,const SwatchDDS& bytes){
    if(path.empty())return false;
    std::ifstream existing(path,std::ios::binary|std::ios::ate);SwatchDDS old{};
    if(existing && existing.tellg()==std::streamoff(old.size())){
        existing.seekg(0);existing.read(reinterpret_cast<char*>(old.data()),old.size());
        if(existing.good()&&old==bytes)return true;
    }
    existing.close();
    auto tmp=path;tmp+=L".gallery-tmp";
    std::ofstream out(tmp,std::ios::binary|std::ios::trunc);out.write(reinterpret_cast<const char*>(bytes.data()),bytes.size());out.close();
    return out.good()&&MoveFileExW(tmp.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH);
}
inline bool writeFinish(unsigned d,unsigned bank,const RgbFinish& c){
    if(d>=8||bank>=(d==5?6u:3u)||!c.valid())return false;
    auto rgb=c.rgb();
    const auto& base=editableMap[d][bank][0];const auto& surface=editableMap[d][bank][1];
    if(base.empty()||surface.empty())return false;
    SwatchDDS before{};std::ifstream input(base,std::ios::binary);
    const bool previous=bool(input.read(reinterpret_cast<char*>(before.data()),before.size()));input.close();
    if(!writeMap(base,swatchDDS(rgb>>16,(rgb>>8)&255,rgb&255)))return false;
    if(writeMap(surface,swatchDDS(0,(c.rough*255+50)/100,(c.metal*255+50)/100)))return true;
    if(previous)writeMap(base,before);
    return false;
}
}



