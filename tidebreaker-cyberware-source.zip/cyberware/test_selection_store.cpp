#include "selection_store.h"
#include "attachment_policy.h"
#include <cassert>
using namespace cyberware;
int wmain(int argc,wchar_t** argv){
    assert(argc==3);std::wstring mode=argv[1],file=argv[2];Selection outfit;
    if(mode==L"write"){
        outfit.enabled[0]=outfit.enabled[20]=true;outfit.finishes[0]=static_cast<Finish>(4);
        ArtProfile p;p.custom=true;materialBanks[0][0]=p.pack();rgbBanks[0][0]={20,40,60,70,80,90};
        assert(storeSelection(file,outfit));return 0;
    }
    assert(loadSelection(file,outfit));loadBanks(file);
    assert(outfit.enabled[0]&&outfit.enabled[20]&&unsigned(outfit.finishes[0])==4);
    assert(ArtProfile::unpack(materialBanks[0][0].load()).custom);
    auto rgb=rgbBanks[0][0];assert(rgb.r==20&&rgb.g==40&&rgb.b==60&&rgb.brightness==70&&rgb.metal==80&&rgb.rough==90);
    RestoreWindow window;Selection blank;
    assert(!window.dueFor(blank,outfit,0));assert(window.dueFor(blank,outfit,1500));window.tried(1500,true);
    assert(!window.dueFor(blank,outfit,1501));assert(!window.dueFor(outfit,outfit,2000));
    assert(!window.dueFor(blank,outfit,4000));assert(!window.dueFor(blank,outfit,5500));assert(window.dueFor(blank,outfit,6500));
    window.tried(6500,true);
    assert(!window.dueFor(outfit,outfit,7000));
    assert(window.dueFor(blank,outfit,11500));window.tried(11500,true);
    assert(!window.dueFor(outfit,outfit,12000));
    assert(!window.dueFor(blank,outfit,20000)); // Brief success cannot reset retry budget.
    assert(!window.dueFor(outfit,outfit,21000));
    assert(!window.dueFor(outfit,outfit,31000)); // Sustained stable state permits a later load restore.
    assert(!window.dueFor(blank,outfit,32000));assert(window.dueFor(blank,outfit,33500));
    RestoreWindow skin;
    assert(!skin.dueFor(outfit,outfit,0,false));
    assert(skin.dueFor(outfit,outfit,1500,false));skin.tried(1500,true);
    assert(!skin.dueFor(outfit,outfit,1750,true));
    assert(!skin.dueFor(outfit,outfit,10000,true));
    Look look{};look[3]=99;assert(Encode(outfit,look));Selection restored;assert(Decode(look,restored)&&sameEquipped(restored,outfit)&&look[3]==99);
    assert(storeSelection(file,blank));assert(loadSelection(file,restored)&&restored==blank);
    assert(WritePrivateProfileStringW(L"DamiElf",L"Design0",L"1,400",file.c_str()));
    assert(!loadSelection(file,restored));
}
