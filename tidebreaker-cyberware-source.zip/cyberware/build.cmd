@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cd /d "%~dp0"
if not exist build mkdir build
pushd build
rc /nologo /fo table.res ..\table.rc
if errorlevel 1 exit /b 1
set "CCSRC=%~dp0dependencies\CharacterCreator"
set "MHSRC=%~dp0dependencies\minhook"
cl /nologo /std:c++17 /EHsc /W4 ..\test_menu_state.cpp /Fetest_menu.exe >tests-build.log 2>&1
if errorlevel 1 exit /b 1
test_menu.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 ..\test_gallery_layout.cpp /Fetest_gallery_layout.exe /link user32.lib >>tests-build.log 2>&1
if errorlevel 1 exit /b 1
test_gallery_layout.exe "%CD%\gallery-layout-test.ini"
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 ..\test_rgb.cpp /Fetest_rgb.exe /link user32.lib >>tests-build.log 2>&1
if errorlevel 1 exit /b 1
test_rgb.exe "%CD%"
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 /DUNICODE /D_UNICODE ..\test_edit_navigation.cpp /Fetest_edit_navigation.exe /link user32.lib >>tests-build.log 2>&1
if errorlevel 1 exit /b 1
test_edit_navigation.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 ..\test_selection_store.cpp /Fetest_selection_store.exe /link user32.lib >>tests-build.log 2>&1
if errorlevel 1 exit /b 1
test_selection_store.exe write "%CD%\outfit-test.ini"
if errorlevel 1 exit /b 1
test_selection_store.exe read "%CD%\outfit-test.ini"
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 ..\test_attachment.cpp /Fetest_attachment.exe >>tests-build.log 2>&1
if errorlevel 1 exit /b 1
test_attachment.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 /DUNICODE /D_UNICODE ..\test_registration.cpp /Fetest_registration.exe table.res /link advapi32.lib >>tests-build.log 2>&1
if errorlevel 1 exit /b 1
cl /nologo /O2 /c /I"%MHSRC%\include" "%MHSRC%\src\buffer.c" "%MHSRC%\src\hook.c" "%MHSRC%\src\trampoline.c" "%MHSRC%\src\hde\hde64.c" >minhook-build.log 2>&1
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 /O2 /DUNICODE /D_UNICODE /I"%CCSRC%" /I"%MHSRC%\include" /LD ..\main.cpp ..\native_backend.cpp ..\art_reader.cpp "%CCSRC%\addresses.cpp" ..\desktop_overlay.cpp "%CCSRC%\log.cpp" "%CCSRC%\switches.cpp" buffer.obj hook.obj trampoline.obj hde64.obj table.res /link /OUT:CyberwareCompanion.asi d2d1.lib dwrite.lib windowscodecs.lib user32.lib gdi32.lib ole32.lib psapi.lib advapi32.lib >plugin-build.log 2>&1
exit /b %errorlevel%





