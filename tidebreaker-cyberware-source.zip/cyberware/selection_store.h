#pragma once
#include "art_profile.h"
#include "menu_state.h"
#include <filesystem>
namespace cyberware {
inline bool loadSelection(const std::wstring& path,Selection& result){
    Selection parsed{};bool found=false;
    for(size_t i=0;i<DesignCount;++i){
        const auto key=L"Design"+std::to_wstring(i);wchar_t val[32]{};
        if(!GetPrivateProfileStringW(L"DamiElf",key.c_str(),L"",val,32,path.c_str()))continue;
        if(WaveHomes[i]<0)continue;
        int enabled=-1,finish=-1;wchar_t tail=0;
        if(swscanf_s(val,L"%d,%d%c",&enabled,&finish,&tail,1u)!=2 ||
           (enabled!=0 && enabled!=1) || finish<0 || unsigned(finish)>=FinishCounts[i])return false;
        parsed.enabled[i]=enabled!=0;parsed.finishes[i]=static_cast<Finish>(finish);found=true;
    }
    if(!found||!Valid(parsed))return false;
    result=parsed;return true;
}
inline bool storeSelection(const std::wstring& path,const Selection& outfit){
    if(!Valid(outfit))return false;
    const std::wstring temp=path+L".tmp."+std::to_wstring(GetCurrentProcessId());
    std::wstring section;
    for(size_t i=0;i<DesignCount;++i){
        section+=L"Design"+std::to_wstring(i)+L"="+(outfit.enabled[i]?L"1,":L"0,")+std::to_wstring(unsigned(outfit.finishes[i]));
        section.push_back(0);
    }
    bool ok=WritePrivateProfileSectionW(L"DamiElf",section.c_str(),temp.c_str()) && saveBanksTo(temp);
    if(ok){WritePrivateProfileStringW(nullptr,nullptr,nullptr,temp.c_str());
        ok=MoveFileExW(temp.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)!=0;}
    if(!ok)DeleteFileW(temp.c_str());
    return ok;
}
inline bool sameEquipped(const Selection& a,const Selection& b){
    for(size_t i=0;i<DesignCount;++i)
        if(a.enabled[i]!=b.enabled[i] || (a.enabled[i] && a.finishes[i]!=b.finishes[i]))return false;
    return true;
}
// Observe a settled mismatch before asking the existing guarded backend to equip anything.
struct RestoreWindow {
    bool tracking=false,settling=false;unsigned attempts=0;ULONGLONG due=0,stableSince=0;Selection observed{};
    void reset(){tracking=false;settling=false;attempts=0;}
    bool dueFor(const Selection& current,const Selection& desired,ULONGLONG now,bool surfaceReady=true){
        if(sameEquipped(current,desired)&&surfaceReady){
            if(!settling){settling=true;stableSince=now;}
            if(now-stableSince>=10000)reset();
            return false;
        }
        settling=false;
        if(!tracking||!sameEquipped(observed,current)){
            observed=current;tracking=true;due=(std::max)(due,now+1500);
        }
        return attempts<3 && now>=due;
    }
    void tried(ULONGLONG now,bool accepted){due=now+(accepted?5000:1000);++attempts;}
};
}
