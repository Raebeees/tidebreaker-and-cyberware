#pragma once
#include <array>
#include <algorithm>
namespace cyberware {
inline constexpr const wchar_t* WaveAreas[]={L"Full face",L"Cheeks",L"Left cheek",L"Right cheek",L"Forehead",L"Scalp",L"Jaw",L"Temples",L"Eyes",L"Neck",L"Mouth / teeth",L"Hands"};
inline constexpr int WaveHomes[]={0,1,2,3,4,5,6,7,1,8,9,-1,-1,-1,-1,-1,-1,11,11,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10};
inline constexpr const wchar_t* WaveTitles[]={L"02 Dual lines",L"02 Dual cut lines",L"02 Left lines",L"02 Right lines",L"04 Face outline",L"04 Scalp / back shell",L"04 Jaw / neck shell",L"Original dual plates",L"Karina Lee",L"TYPE-11 Gold",L"Kurt neck",L"Cyber Spine 1",L"Cyber Spine 2",L"Cyber Spine 3",L"Cyber Spine 4",L"Cyber Spine 5",L"Cyber Spine 6",L"Thiago left hand",L"Thiago right hand",L"Silver braces",L"Base teeth",L"Style 1 / 1",L"Style 1 / 2",L"Style 1 / 3",L"Style 1 / 4",L"Style 1 / 5",L"Style 1 / 6",L"Style 2 / 1",L"Style 2 / 2",L"Style 2 / 3",L"Style 2 / 4",L"Style 2 / 5",L"Style 2 / 6",L"Style 3 / 1",L"Style 3 / 2",L"Style 3 / 3",L"Style 3 / 4",L"Style 3 / 5",L"Style 3 / 6",L"Style 4 / 1",L"Style 4 / 2",L"Style 4 / 3",L"Style 4 / 4",L"Style 4 / 5",L"Style 4 / 6"};
inline constexpr int WaveDesignCount=int(std::size(WaveHomes));
inline constexpr int WaveAreaCount=int(std::size(WaveAreas));

inline constexpr bool WaveAvailable[WaveDesignCount-8]={true,true,true,false,false,false,false,false,false,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true};
struct WaveTile { float x,y,w,h; };
inline int AreaSize(int area){
    return int(std::count(std::begin(WaveHomes),std::end(WaveHomes),area));
}
inline WaveTile TileAt(int area,int ordinal){
    const int count=AreaSize(area);
    if(count<=0 || ordinal<0 || ordinal>=count)return {};
    const int columns=count<=3?count:(count<=9?3:6);
    const int rows=(count+columns-1)/columns;
    const float w=960.f/(std::max)(1,columns),h=286.f/(std::max)(1,rows);
    return {18.f+(ordinal%columns)*w,73.f+(ordinal/columns)*h,w-6,h-6};
}
inline int GalleryHit(int area,float x,float y){
    if(area<0 || area>=WaveAreaCount)return -1;
    int ordinal=0;
    for(int i=0;i<WaveDesignCount;i++)if(WaveHomes[i]==area){
        auto b=TileAt(area,ordinal++);
        if(x>=b.x&&x<b.x+b.w&&y>=b.y&&y<b.y+b.h)return i;
    }
    return -1;
}
inline WaveTile BodyTile(int area){
    return {20.f+202.f*(area%2),90.f+59.f*(area/2),194.f,52.f};
}
inline int BodyHit(float x,float y){
    for(int a=0;a<WaveAreaCount;++a){
        const auto t=BodyTile(a);
        if(x>=t.x&&x<t.x+t.w&&y>=t.y&&y<t.y+t.h)return a;
    }
    return -1;
}
}
