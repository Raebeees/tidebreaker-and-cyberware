#include "spectrum_picker.h"
#include "art_profile.h"
#include <cassert>
using namespace cyberware;
int wmain(int argc,wchar_t** argv){
    assert(argc==2);auto dir=std::filesystem::path(argv[1]);auto base=dir/L"rgb-test-base.dds",surface=dir/L"rgb-test-surface.dds";
    editableMap[0][0][0]=base;editableMap[0][0][1]=surface;
    RgbFinish c{241,147,21,50,67,34};assert(writeFinish(0,0,c));
    assert(isGeneratedMap(marker(0,0,"base"),base)&&isGeneratedMap(marker(0,0,"surface"),surface));
    assert(!isGeneratedMap("anything_else",base));
    auto read=[](auto file){SwatchDDS bytes;std::ifstream f(file,std::ios::binary);f.read((char*)bytes.data(),bytes.size());return bytes;};
    assert(read(base)==swatchDDS(121,74,11));assert(read(surface)==swatchDDS(0,87,171));
    ArtProfile a;a.custom=true;assert(ArtProfile::unpack(a.pack()).custom&&a.valid(0));
    SpectrumPicker p;assert(p.pointer(WM_LBUTTONDOWN,34,285));assert(p.finish.rgb()==0xff0000);
    assert(p.pointer(WM_LBUTTONUP,34+594.f/3,285));assert(p.finish.rgb()==0x00ff00);
    assert(p.pointer(WM_LBUTTONDOWN,160,310));assert(p.pointer(WM_LBUTTONUP,626,310));assert(p.finish.r==255);
}
