#include "prefab_guard.h"
int wmain(int argc,wchar_t** argv) {
    return argc==2 && prefab_guard::compatible(argv[1]) ? 0 : 1;
}
