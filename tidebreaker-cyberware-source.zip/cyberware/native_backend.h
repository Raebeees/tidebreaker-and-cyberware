#pragma once
#include "menu_state.h"
namespace cyberware {
class NativeBackend final:public CombinedBackend {
public:
    bool initialize(const wchar_t* recoveryFile);
    bool ready()const override;
    bool apply(const Selection&)override;
    bool confirmed(const Selection&)const override;
    Selection current()const;
    bool surfaceReady(const Selection&)const;
};
}
