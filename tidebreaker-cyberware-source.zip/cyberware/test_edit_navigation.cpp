#include "menu_panel.h"
#include <cassert>
using namespace cyberware;
struct Backend : CombinedBackend {
    bool ready()const override{return true;}
    bool apply(const Selection&)override{return true;}
    bool confirmed(const Selection&)const override{return true;}
};
int main(){
    RegionMenu menu;Backend backend;menu.begin({});
    menu.layout.width=1000;menu.layout.height=556;menu.layout.standalone=true;
    auto click=[&](float x,float y){assert(menu.pointer(WM_LBUTTONDOWN,x/1000,y/556,backend));menu.pointer(WM_LBUTTONUP,x/1000,y/556,backend);};
    auto has=[&](const wchar_t* label){bool found=false;menu.controls([&](auto b){found|=!wcscmp(b.text,label);});return found;};
    click(35,103);click(42,530);assert(menu.session.preview.enabled[0]&&has(L"Remove"));
    click(42,530);assert(!menu.session.preview.enabled[0]&&has(L"Equip"));
    artReady=true;click(550,450);assert(has(L"Back"));
    click(900,55);assert(menu.session.preview.enabled[0]&&has(L"Back"));
    auto first=menu.session.preview.finishes[0];
    menu.key(VK_F2,backend);menu.key('B',backend);menu.key(VK_RETURN,backend);
    assert(menu.session.preview.finishes[0]!=first&&has(L"Back"));
    click(840,530);assert(has(L"Body areas"));click(850,20);assert(has(L"Done"));
    click(35,400); // Mouth and teeth
    click(45,530);assert(menu.session.preview.enabled[19]);
    auto second=TileAt(10,1);click(second.x+5,second.y+5);click(45,530);
    assert(!menu.session.preview.enabled[19]&&menu.session.preview.enabled[20]);
    assert(menu.key(VK_ESCAPE,backend)&&has(L"Done"));
    assert(menu.key(VK_ESCAPE,backend)&&!menu.session.visible&&menu.session.preview.enabled[20]);
}
