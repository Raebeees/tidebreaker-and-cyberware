#include <windows.h>
#include <atomic>
#include <cstring>
#include <string>
#include "native_backend.h"
#include "art_profile.h"
#include "attachment_policy.h"
#include "registration_guard.h"
#include "contact_runtime.h"
#include "addresses.h"
#include "log.h"
#include "skin_trace.h"
namespace {
using Tick=uint64_t(__fastcall*)(uint64_t,uint64_t,uint64_t,uint64_t);
using Queue=void(__fastcall*)(uintptr_t,const uint8_t*);
using Rebuild=void(__fastcall*)(uintptr_t,uintptr_t);
Tick previous=nullptr;Queue queue=nullptr;Rebuild rebuild=nullptr;
uintptr_t vt=0,appearanceVtable=0,owner=0;DWORD firstSeen=0;
std::atomic<DWORD> seen{0};std::atomic<bool> initialized{false},eligible{false};
SRWLOCK stateLock=SRWLOCK_INIT;
cyberware::Look observed{},lastApplied{};cyberware::Selection requested{};
cyberware::Request request;cyberware::HairLease hair,plannedHair;
bool awaiting=false,confirmedRequest=false;DWORD appliedAt=0;
std::wstring recovery;
bool read(uintptr_t p,void* out,size_t n){__try{memcpy(out,(void*)p,n);return true;}__except(EXCEPTION_EXECUTE_HANDLER){return false;}}
unsigned options(uintptr_t c,unsigned slot){
    uintptr_t table=0,rows=0;unsigned count=0,result=0;
    if(!read(c+0x128,&table,8)||!table||!read(table+0x50,&count,4)||slot>=count||count>32||!read(table+0x48,&rows,8)||!rows)return 0;
    read(rows+slot*0xc0+0xb8,&result,4);return result;
}
bool readyNow(){return initialized&&eligible&&GetTickCount()-seen.load()<1000;}
bool persistHair(const cyberware::HairLease& value){
    wchar_t text[16];swprintf_s(text,L"%u",value.original);
    // Commit recovery before hiding hair, so a crash/reload does not lose it.
    return WritePrivateProfileStringW(L"DamiElf",L"OriginalHair",text,recovery.c_str())&&
        WritePrivateProfileStringW(L"DamiElf",L"HairOwned",value.owned?L"1":L"0",recovery.c_str());
}
bool change(uintptr_t c,uintptr_t meshes,uintptr_t holder,const cyberware::Look& from,const cyberware::Look& to){
    const bool previousTrace=skin_trace::playerRebuild;
    __try{
        for(int slot:{0,1,2,4,6,7,8,9,10,11,12,13,14,15})if(cyberware::QueueSlot(slot,from,to)){
            uint8_t command[3]={(uint8_t)slot,from[slot]==255?uint8_t(0):from[slot],to[slot]};
            queue(c+0xf8,command);*(uint8_t*)(meshes+slot)=to[slot];
        }
        skin_trace::playerRebuild=true;++skin_trace::epoch;
        rebuild(c,holder);skin_trace::playerRebuild=previousTrace;return true;
    }__except(EXCEPTION_EXECUTE_HANDLER){skin_trace::playerRebuild=previousTrace;return false;}
}
void update(uintptr_t c){
    uintptr_t v=0,meshes=0;unsigned count=0;cyberware::Look look{};
    if(!read(c,&v,8)||v!=vt||options(c,5)!=217||!read(c+0xa0,&meshes,8)||!meshes||!read(c+0xa8,&count,4)||count!=16||!read(meshes,look.data(),16)||!contact::body(look[0])){
        if(owner==c){eligible=false;request.pending=false;awaiting=false;}return;
    }
    for(int slot:{4,6,7,8,9,10,11,12,13,14,15})if(options(c,slot)!=cyberware::SlotCounts[slot]){if(owner==c)eligible=false;return;}
    DWORD now=GetTickCount();
    if(owner!=c){
        if(owner&&now-seen.load()<3000)return;
        owner=c;firstSeen=now;eligible=false;request.pending=false;awaiting=false;confirmedRequest=false;hair={};
        if(look[8]!=0&&look[8]!=255){
            if(GetPrivateProfileIntW(L"DamiElf",L"HairOwned",0,recovery.c_str())){
                hair.owned=true;hair.original=(uint8_t)GetPrivateProfileIntW(L"DamiElf",L"OriginalHair",255,recovery.c_str());
            }
            else if(look[2]!=255){hair.owned=true;hair.original=look[2];}
            else {Log("cyberware: scalp loaded without a hair recovery record; keeping hair None on removal");hair.owned=true;hair.original=255;}
        }
    }
    if(observed[0]!=look[0]||observed[1]!=look[1])
        Log("cyberware: skin readback body=%u head=%u (previous %u/%u)",look[0],look[1],observed[0],observed[1]);
    seen=now;observed=look;if(now-firstSeen<5000)return;
    uintptr_t holder=0,kind=0;cyberware::Selection parsed;
    eligible=contact::head(look[1])&&options(c,0)==contact::BodyBase+3&&options(c,1)==contact::HeadBase+3&&read(c+0x138,&holder,8)&&holder&&read(holder,&kind,8)&&kind==appearanceVtable&&cyberware::Decode(look,parsed)&&
        (look[6]==255||look[6]<cyberware::SlotCounts[6])&&(look[2]==255||look[2]<options(c,2));
    if(!eligible){request.pending=false;awaiting=false;confirmedRequest=false;return;}
    if(look[12]>=1 && look[12]<=6){
        auto withoutSpine=look;
        withoutSpine[12]=0;
        request.pending=false;awaiting=false;confirmedRequest=false;
        if(!change(c,meshes,holder,look,withoutSpine)){initialized=false;eligible=false;return;}
        observed=withoutSpine;
        Log("cyberware: removed retired spine option %u",unsigned(look[12]));
        return;
    }
    if(awaiting){
        if(cyberware::OwnedEqual(look,lastApplied)){
            awaiting=false;confirmedRequest=true;Log("cyberware: all attachment and coverage slots confirmed");
            // For Off, retain recovery until the actual game readback confirms it.
            if(!hair.owned)persistHair(hair);
        }else if(now-appliedAt>1000){awaiting=false;confirmedRequest=false;Log("cyberware: confirmation timed out; no automatic retry");}
        return;
    }
    if(!request.pending)return;
    if(!request.consume(look,now)){confirmedRequest=false;Log("cyberware: request canceled after external appearance change or timeout");return;}
    if(plannedHair.owned&&!persistHair(plannedHair)){Log("cyberware: recovery could not be saved; attachment request refused");return;}
    Log("cyberware: apply face=%u right=%u scalp=%u jaw=%u brow=%u hair=%u waveFace=%u neck=%u spine=%u leftHand=%u rightHand=%u mouth=%u",request.desired[4],request.desired[7],request.desired[8],request.desired[9],request.desired[6],request.desired[2],request.desired[10],request.desired[11],request.desired[12],request.desired[13],request.desired[14],request.desired[15]);
    Log("cyberware: skin request body=%u head=%u -> body=%u head=%u",look[0],look[1],request.desired[0],request.desired[1]);
    if(!change(c,meshes,holder,look,request.desired)){initialized=false;eligible=false;Log("cyberware: native change fault; backend disabled");return;}
    hair=plannedHair;lastApplied=request.desired;awaiting=true;appliedAt=now;confirmedRequest=false;
}
uint64_t __fastcall tick(uint64_t c,uint64_t a,uint64_t b,uint64_t d){
    uint64_t result=previous(c,a,b,d);
    if(initialized&&TryAcquireSRWLockExclusive(&stateLock)){update((uintptr_t)c);ReleaseSRWLockExclusive(&stateLock);}return result;
}
}
bool cyberware::NativeBackend::initialize(const wchar_t* recoveryFile){
    recovery=recoveryFile;
    wchar_t modulePath[MAX_PATH]{};GetModuleFileNameW(nullptr,modulePath,MAX_PATH);
    contact::dataRoot=std::filesystem::path(modulePath).parent_path()/L"CyberwareCompanion/Contact";
    if(!RegistrationVerified()){Log("cyberware: mounted registration failed exact guard; no hook installed");return false;}
    const auto base=reinterpret_cast<uintptr_t>(GetModuleHandleW(nullptr));
    const auto dos=reinterpret_cast<const IMAGE_DOS_HEADER*>(base);
    const auto nt=reinterpret_cast<const IMAGE_NT_HEADERS*>(base+dos->e_lfanew);
    struct Build { DWORD stamp,size,controller,queue,rebuild,appearance,xml; };
    static constexpr Build supported[]={
        {0x6ae6e3e8,0x14073000,0x5925590,0x805120,0x7fe1c0,0x5d7b678,0x160e170}, // 3479
        {0x6aea07a6,0x13eb2000,0x592b5b8,0x805ef0,0x7fef90,0x5d818d0,0x160f680}, // 3527
        {0x6aeb7d59,0x13cff000,0x592b5b8,0x805ef0,0x7fef90,0x5d818d0,0x160f680}, // Steam 26448710
        {0x6aed2e85,0x13cc4000,0x592d678,0x806590,0x7ff630,0x5d83790,0x160fea0} // Steam 26480954
    };
    const Build* build=nullptr;
    for(const auto& b:supported)
        if(nt->FileHeader.TimeDateStamp==b.stamp&&nt->OptionalHeader.SizeOfImage==b.size)build=&b;
    if(!build){Log("cyberware: unsupported executable");return false;}
    AddressesInit();
    vt=AddressOf(ADDR_CONTROLLERVTABLE);queue=(Queue)AddressOf(ADDR_QUEUEMESHCHANGE);
    rebuild=(Rebuild)AddressOf(ADDR_REBUILD);appearanceVtable=AddressOf(ADDR_APPEARANCETABLEVTABLE);
    if(vt!=base+build->controller||(uintptr_t)queue!=base+build->queue||(uintptr_t)rebuild!=base+build->rebuild||
       appearanceVtable!=base+build->appearance||AddressOf(ADDR_LOADXML)!=base+build->xml){
        Log("cyberware: executable matched, but attachment or material addresses differed");return false;
    }
    for(unsigned d=0;d<8;d++)for(unsigned bank=0;bank<(d==5?6u:3u);bank++){
        auto value=materialBanks[d][bank].load();
        if(value&&ArtProfile::unpack(value).custom&&!writeFinish(d,bank,rgbBanks[d][bank]))return false;
    }
    auto entry=(void**)(vt+8);void* current=*entry;MEMORY_BASIC_INFORMATION info{};
    if(!VirtualQuery(current,&info,sizeof(info))||info.AllocationBase!=GetModuleHandleW(L"CharacterCreator.asi"))return false;
    DWORD protect=0;if(!VirtualProtect(entry,8,PAGE_READWRITE,&protect))return false;previous=(Tick)current;
    void* prior=InterlockedCompareExchangePointer(entry,(void*)&tick,current);DWORD ignored=0;VirtualProtect(entry,8,protect,&ignored);if(prior!=current)return false;
    initialized=true;Log("cyberware: skin alias recovery; relief substitution DISABLED; native materials preserved");Log("Cyberware material reader %s",InstallMaterialReader()?"ready":"unavailable");Log("cyberware: combined slots 4/7/8/9, coverage 6/2; explicit selections only");return true;
}
bool cyberware::NativeBackend::ready()const{return readyNow();}
bool cyberware::NativeBackend::apply(const Selection& s){
    AcquireSRWLockShared(&stateLock);
    const bool available=readyNow()&&!request.pending&&!awaiting;
    const Look before=observed;
    ReleaseSRWLockShared(&stateLock);
    if(!available)return false;
    Look target=before;
    if(!Encode(s,target)||!contact::prepare(s,before,target))return false;
    AcquireSRWLockExclusive(&stateLock);
    bool ok=readyNow()&&!request.pending&&!awaiting&&before==observed;
    auto nextHair=hair;if(ok){target[2]=nextHair.target(s.enabled[5],observed[2]);ok=target[2]==255||target[2]<195;}
    if(ok){request.begin(observed,target,GetTickCount());requested=s;plannedHair=nextHair;confirmedRequest=false;}
    ReleaseSRWLockExclusive(&stateLock);return ok;
}
bool cyberware::NativeBackend::confirmed(const Selection& s)const{
    AcquireSRWLockShared(&stateLock);
    bool ok=readyNow()&&!request.pending&&!awaiting&&confirmedRequest&&requested==s&&OwnedEqual(observed,lastApplied);
    // Opening and keeping an unchanged native selection needs no rebuild.
    if(!ok&&readyNow()&&!request.pending&&!awaiting){
        Look expected=observed;ok=Encode(s,expected);
        if(ok)for(int slot:{4,6,7,8,9,10,11,12,13,14,15})if(expected[slot]!=(observed[slot]==255?0:observed[slot]))ok=false;
        if(s.enabled[5]&&observed[2]!=255)ok=false;
    }
    ok=ok&&contact::readyFor(s,observed);
    for(unsigned d=0;ok&&d<8;d++)if(s.enabled[d])ok=materialSeen(d,unsigned(s.finishes[d]));
    ReleaseSRWLockShared(&stateLock);return ok;
}
bool cyberware::NativeBackend::surfaceReady(const Selection& s)const{
    AcquireSRWLockShared(&stateLock);
    bool ok=readyNow()&&contact::readyFor(s,observed);
    ReleaseSRWLockShared(&stateLock);return ok;
}
cyberware::Selection cyberware::NativeBackend::current()const{
    AcquireSRWLockShared(&stateLock);Selection s;Decode(observed,s);ReleaseSRWLockShared(&stateLock);return s;
}




