#pragma once
#include "art_profile.h"
#include <vector>
namespace cyberware {
class MaterialPicker {
public:
    ArtProfile value{};
    std::vector<std::wstring> styles;
    std::vector<int> colors,normals;
    unsigned section=1,style=0,design=0;
    bool open=false;
    void list(bool reset){
        const auto &a=ArtLists[design];colors.clear();normals.clear();
        for(int i=0;i<a.colorCount;i++)if(styles[style]==a.colors[i].style)colors.push_back(i);
        for(int i=0;i<a.normalCount;i++)if(!*a.normals[i].style||styles[style]==a.normals[i].style)normals.push_back(i);
        if(reset||std::find(colors.begin(),colors.end(),value.color)==colors.end())value.color=colors.at(0);
        if(reset||std::find(normals.begin(),normals.end(),value.normal)==normals.end())value.normal=normals.at(0);
    }
    void start(unsigned d,unsigned finish){
        design=d;styles.clear();open=true;section=1;
        const auto &a=ArtLists[d];
        for(int i=0;i<a.colorCount;i++)if(std::find(styles.begin(),styles.end(),a.colors[i].style)==styles.end())styles.emplace_back(a.colors[i].style);
        unsigned saved=finish>=4?materialBanks[d][finish-4].load():0;
        value=saved?ArtProfile::unpack(saved):ArtProfile{};
        if(!saved){
            for(int i=0;i<a.normalCount;i++)if(!wcscmp(a.normals[i].name,L"Flat")||!wcscmp(a.normals[i].name,L"Original")){value.normal=i;break;}
            const wchar_t* preset=finish==1?(d<4?L"Silver":L"Chrome"):finish==2?(d<4?L"Metal":L"Iron"):finish==3?L"Gold":L"Black";
            for(int i=0;i<a.colorCount;i++)if(!wcscmp(a.colors[i].name,preset)&&(d!=6||!wcscmp(a.colors[i].style,L"Monochrome"))){value.color=i;break;}
        }
        style=unsigned(std::find(styles.begin(),styles.end(),a.colors[value.color].style)-styles.begin());list(false);
    }
    void select(unsigned i){
        if(section==0&&i<styles.size()){style=i;list(true);}
        if(section==1&&i<colors.size())value.color=colors[i];
        if(section==2&&i<normals.size())value.normal=normals[i];
        if(section==2&&!detail()){if(value.metal>2)value.metal=1;if(value.rough>2)value.rough=1;}
        if(section==3&&i<(detail()?7u:3u))value.metal=i;
        if(section==4&&i<(detail()?7u:3u))value.rough=i;
    }
    bool detail()const{return design==6&&(!wcscmp(ArtLists[6].normals[value.normal].name,L"Original")||!wcscmp(ArtLists[6].normals[value.normal].name,L"Smooth"));}
    std::vector<std::wstring> names(unsigned group)const{
    std::vector<std::wstring> names;
        if(group==0) return styles;
        if(group==1)for(auto i:colors)names.push_back(ArtLists[design].colors[i].name);
        if(group==2)for(auto i:normals)names.push_back(ArtLists[design].normals[i].name);
        if(group>=3){names={L"0%",L"50%",L"100%"};if(detail())names.insert(names.end(),{L"Detail 0%",L"Detail 25%",L"Detail 50%",L"Detail 100%"});}
        return names;
    }
    bool selected(unsigned group,unsigned i) const{
        switch(group){case 0:return style==i;case 1:return colors[i]==value.color;case 2:return normals[i]==value.normal;case 3:return i==unsigned(value.metal);default:return i==unsigned(value.rough);}
    }
};
}


