#pragma once
#include <windows.h>
#include <wincrypt.h>
#include <fstream>
#include <sstream>
#include <filesystem>
#include <string>
#include <vector>
#include "guard_entries.h"
#include "prefab_guard.h"
#include "cc_9136_mount.h"
#include "rgb_finish.h"
#include "contact_runtime.h"
#include "contact_data.h"
inline std::string FileSHA256(const std::filesystem::path& p){
    std::ifstream f(p,std::ios::binary);if(!f)return {};
    HCRYPTPROV provider=0;HCRYPTHASH hash=0;std::string result;
    if(!CryptAcquireContextW(&provider,nullptr,nullptr,PROV_RSA_AES,CRYPT_VERIFYCONTEXT))return {};
    if(CryptCreateHash(provider,CALG_SHA_256,0,0,&hash)){
        char buffer[65536];bool ok=true;
        while(f){f.read(buffer,sizeof(buffer));auto n=f.gcount();if(n&&!CryptHashData(hash,(BYTE*)buffer,(DWORD)n,0)){ok=false;break;}}
        BYTE bytes[32];DWORD size=32;
        if(ok&&f.eof()&&CryptGetHashParam(hash,HP_HASHVAL,bytes,&size,0)&&size==32){const char* hex="0123456789abcdef";for(BYTE b:bytes){result+=hex[b>>4];result+=hex[b&15];}}
        CryptDestroyHash(hash);
    }
    CryptReleaseContext(provider,0);return result;
}
inline bool RegistrationVerifiedAt(const std::filesystem::path& root){
    const auto ccHash=FileSHA256(root/L"CharacterCreator.asi");
    const bool cc9136=ccHash==CC9136Hash;
    if(!cc9136)return false;
    std::ifstream manifest(root/L"dmm/manifest.tsv");if(!manifest)return false;
    std::vector<bool> found(GuardCount,false);std::string line;
    while(std::getline(manifest,line)){
        if(!line.empty()&&line.back()=='\r')line.pop_back();std::istringstream fields(line);std::string kind,path,provider;
        std::getline(fields,kind,'\t');std::getline(fields,path,'\t');std::getline(fields,provider,'\t');if(kind!="file")continue;
        for(size_t i=0;i<GuardCount;i++)if(path==GuardPaths[i]){
                        auto file=std::filesystem::u8path(provider);
            bool writable=false;
            if(found[i])return false;
            for(unsigned d=0;d<8;d++)for(unsigned b=0;b<(d==5?6u:3u);b++)for(unsigned t=0;t<2;t++){
                if(path!=cyberware::marker(d,b,t?"surface":"base"))continue;
                const auto expected=std::filesystem::path(L"C:/Modding/dmm/mods/Cyberware Plate Mesh Diagnostic")/std::filesystem::u8path(path);
                if(!_wcsicmp(expected.lexically_normal().c_str(),file.lexically_normal().c_str())){cyberware::editableMap[d][b][t]=file;writable=true;}
            }
            const char* expectedHash=GuardHashes[i];
            if(cc9136&&path=="character/bin__/partprefabtable.pappt")expectedHash=CC9136PrefabHash;
            if(cc9136&&path=="character/descriptors/customizationmeta/meshparam_example_kliff.xml")expectedHash=CC9136KliffHash;
            const auto actual=FileSHA256(file);
            if(actual!=expectedHash &&
                !(path=="character/bin__/partprefabtable.pappt" && prefab_guard::compatible(file)) &&
                !(writable&&cyberware::isGeneratedMap(path,file)) && !contact::generated(path,file))return false;
            found[i]=true;
        }
    }
    for(bool value:found)if(!value)return false;
    for(const auto& row:ContactData)if(FileSHA256(root/L"CyberwareCompanion/Contact"/row.name)!=row.hash)return false;
    return true;
}
inline bool RegistrationVerified(){wchar_t exe[MAX_PATH]{};GetModuleFileNameW(nullptr,exe,MAX_PATH);return RegistrationVerifiedAt(std::filesystem::path(exe).parent_path());}





