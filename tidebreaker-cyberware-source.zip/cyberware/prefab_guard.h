#pragma once
#include <windows.h>
#include <filesystem>
#include <fstream>
#include <string_view>
#include <unordered_set>
#include <vector>

namespace prefab_guard {
using Bytes = std::string_view;
struct Row { Bytes name, raw; };
struct Table { std::vector<Row> parts, heads; };

class Reader {
    Bytes remaining;
public:
    explicit Reader(Bytes bytes) : remaining(bytes) {}
    bool empty() const { return remaining.empty(); }
    Bytes tail() const { return remaining; }
    bool take(size_t count, Bytes& out) {
        if (count > remaining.size()) return false;
        out = remaining.substr(0, count);
        remaining.remove_prefix(count);
        return true;
    }
    bool byte(unsigned& value) {
        Bytes b;
        if (!take(1,b)) return false;
        value = static_cast<unsigned char>(b[0]);
        return true;
    }
    bool text(Bytes& value) {
        unsigned size;
        if (!byte(size) || !size || !take(size,value) || value.back()!=0) return false;
        value.remove_suffix(1);
        return value.find('\0')==Bytes::npos;
    }
    bool rows(std::vector<Row>& result, bool heads) {
        Bytes data;
        if (!take(4,data)) return false;
        uint32_t count;
        memcpy(&count,data.data(),4);
        if (count > remaining.size()/4) return false;
        for (uint32_t i=0;i<count;++i) {
            Bytes before=remaining,name,unused;
            if (!text(name)||!text(unused)) return false;
            if (!heads) {
                unsigned tag,flag,parts;
                if (!text(unused)||!byte(tag)||tag!=1||!text(unused)||!byte(flag)||!byte(parts)) return false;
                for (unsigned j=0;j<parts;++j) if (!text(unused)||!byte(flag)) return false;
            }
            result.push_back({name,before.substr(0,before.size()-remaining.size())});
        }
        return true;
    }
};

inline bool parse(Bytes bytes, Table& table) {
    Reader reader(bytes);
    Bytes header;
    return reader.take(8,header) && header==Bytes("\0\0\0\0\0\0\0\0",8) &&
        reader.rows(table.parts,false) && reader.rows(table.heads,true) && reader.empty();
}
inline std::string key(Bytes name) {
    std::string result(name);
    for (auto& c:result) if(c>='A'&&c<='Z') c=char(c-'A'+'a');
    return result;
}
inline bool additionsOnly(Bytes baseline, Bytes mounted) {
    Table original,current;
    if (!parse(baseline,original)||!parse(mounted,current)) return false;
    std::unordered_set<std::string> reserved;
    for (auto rows:{&original.parts,&original.heads})
        for (const auto& row:*rows) reserved.insert(key(row.name));
    auto matches=[&](const auto& expected,const auto& actual) {
        size_t i=0;
        std::unordered_set<std::string> extra;
        for (const auto& row:actual) {
            if (i<expected.size() && row.raw==expected[i].raw) {++i;continue;}
            auto name=key(row.name);
            if (name.empty()||reserved.count(name)||!extra.insert(name).second) return false;
        }
        return i==expected.size();
    };
    return matches(original.parts,current.parts)&&matches(original.heads,current.heads);
}
extern "C" IMAGE_DOS_HEADER __ImageBase;
inline bool compatible(const std::filesystem::path& path) {
    auto module=reinterpret_cast<HMODULE>(&__ImageBase);
    auto resource=FindResourceW(module,MAKEINTRESOURCEW(101),MAKEINTRESOURCEW(10));
    if (!resource) return false;
    auto baseline=static_cast<const char*>(LockResource(LoadResource(module,resource)));
    if (!baseline) return false;
    std::ifstream f(path,std::ios::binary|std::ios::ate);
    const auto size=f.tellg();
    if (size<=0 || size>64*1024*1024) return false;
    std::string data(static_cast<size_t>(size),'\0');
    f.seekg(0);
    if (!f.read(data.data(),size)) return false;
    return additionsOnly(Bytes(baseline,SizeofResource(module,resource)),data);
}
}
