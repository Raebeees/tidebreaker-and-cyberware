#include <cassert>
#include "menu_state.h"
using namespace cyberware;
struct Fake:CombinedBackend {
    bool available=true,settled=false,accept=true;int calls=0;Selection pending{};
    bool ready()const override{return available;}
    bool apply(const Selection& s)override{calls++;if(!accept)return false;pending=s;settled=false;return true;}
    bool confirmed(const Selection& s)const override{return available&&settled&&pending==s;}
};
int main(){
    Fake b;CombinedSession s;s.open({});assert(b.calls==0);
    // Separate left/right designs retain distinct materials.
    assert(s.choose(b,2,true,Finish::Chrome));assert(s.choose(b,3,true,Finish::Gold));
    assert(s.preview.enabled[2]&&s.preview.enabled[3]);assert(s.preview.finishes[2]==Finish::Chrome&&s.preview.finishes[3]==Finish::Gold);
    auto before=s.preview;int calls=b.calls;
    // Linked dual design conflicts with an already selected side.
    assert(!s.choose(b,0,true,Finish::Black));assert(s.preview==before&&calls==b.calls);
    assert(!s.commit(b));assert(!s.cancel(b));assert(s.visible&&s.canceling);
    assert(!s.choose(b,2,false,Finish::Chrome));b.settled=true;assert(s.cancel(b));assert(s.preview==Selection{});
    // Rejected application cannot modify UI state; failed cancel keeps window open.
    s.open(before);b.accept=false;assert(!s.choose(b,2,false,Finish::Chrome));assert(s.preview==before);
    b.accept=true;assert(s.choose(b,2,false,Finish::Chrome));b.available=false;assert(!s.cancel(b));assert(s.visible);
    b.available=true;assert(!s.cancel(b));b.settled=true;assert(s.cancel(b));assert(s.preview==before);
    s.open({});assert(!s.choose(b,DesignCount,true,Finish::Black));assert(!s.choose(b,0,true,static_cast<Finish>(9)));
    assert(OccupiedRegions(before)==(DesignRegions[2]|DesignRegions[3]));
    // No imported asset is silently exposed as body cyberware.
    for(size_t i=0;i<8;i++)assert((DesignRegions[i]>>9)==0);
    for(int a=0;a<WaveAreaCount;++a){auto t=BodyTile(a);assert(BodyHit(t.x+t.w/2,t.y+t.h/2)==a);assert(BodyHit(t.x+t.w+1,t.y+3)==-1);}
    int seen[WaveDesignCount]={};
    for(int a=0;a<WaveAreaCount;++a) for(int j=0;j<AreaSize(a);++j){
        auto tile=TileAt(a,j);int d=GalleryHit(a,tile.x+tile.w/2,tile.y+tile.h/2);
        assert(d>=0 && WaveHomes[d]==a);++seen[d];
    }
    assert(WaveAreaCount==12 && AreaSize(11)==2 && GalleryHit(-1,19,74)==-1);
    for(int i=0;i<WaveDesignCount;++i)assert(seen[i]==(i<11 || i>16));
}
