#include <windows.h>
#include <mutex>
#include <string>
#include "menu_panel.h"
#include "selection_store.h"
#include "native_backend.h"
#include "log.h"
#include "switches.h"
static HMODULE module;
static std::mutex menuLock;
static cyberware::RegionMenu menu;
static cyberware::NativeBackend backend;
static std::wstring folder;
static PVOID volatile requestedWindow=nullptr;
extern "C" __declspec(dllexport) void WINAPI OpenCyberwareGallery(HWND owner){
    DWORD pid=0;GetWindowThreadProcessId(owner,&pid);
    if(pid==GetCurrentProcessId())InterlockedExchangePointer(&requestedWindow,owner);
}
static cyberware::Selection outfit;
static cyberware::RestoreWindow restore;
static bool haveOutfit=false,needsWrite=false,bootstrap=false;
static ULONGLONG nextWrite=0,nextPoll=0;
static std::wstring profile;
static void persist(){
    needsWrite=!cyberware::storeSelection(profile,outfit);
    nextWrite=GetTickCount64()+5000;
    menu.saveStatus=needsWrite?L"Could not save cyberware. Retrying...":L"Cyberware saved";
    if(needsWrite)Log("cyberware: could not write selection profile");
}
static void remember(const cyberware::Selection& value){
    outfit=value;haveOutfit=true;bootstrap=false;restore.reset();persist();
}
static void beginGallery(){
    restore.reset();menu.begin(haveOutfit?outfit:backend.current());OverlaySetVisible(true);
}
static void afterInput(unsigned before,bool wasOpen){
    if(menu.session.edits!=before)remember(menu.session.preview);
    if(wasOpen&&!menu.session.visible){
        if(haveOutfit && !(outfit==menu.session.preview))remember(menu.session.preview);
        OverlaySetVisible(false);
    }
}
static void reconcile(){
    const auto now=GetTickCount64();
    if(needsWrite&&now>=nextWrite)persist();
    if(now<nextPoll)return;
    nextPoll=now+250;
    if(!backend.ready())return;
    if(menu.session.canceling)return;
    auto current=backend.current();
    if(bootstrap){
        // First upgrade: prefer the outfit actually equipped once the native controller is stable.
        bool wearing=std::any_of(current.enabled.begin(),current.enabled.end(),[](bool x){return x;});
        if(wearing||haveOutfit){
            remember(wearing?current:outfit);
            if(menu.session.visible)menu.session.open(outfit);
        }else return;
    }
    if(!haveOutfit)return;
    if(restore.dueFor(current,outfit,now,backend.surfaceReady(outfit))){
        bool accepted=backend.apply(outfit);restore.tried(now,accepted);
        if(accepted)Log("cyberware: requested saved loadout on ready DamiElf");
        if(restore.attempts==3)menu.saveStatus=L"Saved outfit pending. Reopen the gallery to retry.";
    }else if(cyberware::sameEquipped(current,outfit)&&!needsWrite){
        menu.saveStatus=L"Cyberware saved";
    }
}
static void key(int key){
    std::lock_guard<std::mutex> guard(menuLock);bool was=menu.session.visible;
    auto before=menu.session.edits;menu.key(key,backend);
    afterInput(before,was);
}
bool GalleryPointer(HWND window,UINT msg,LPARAM position){
    RECT rect{};
    if(!GetClientRect(window,&rect)||rect.right<=0||rect.bottom<=0)return false;
    std::lock_guard<std::mutex> guard(menuLock);
    if(!menu.session.visible)return false;
    auto before=menu.session.edits;bool handled=menu.pointer(msg,static_cast<short>(LOWORD(position))/float(rect.right),static_cast<short>(HIWORD(position))/float(rect.bottom),backend);
    afterInput(before,true);
    return handled;
}
static void draw(const OverlayDrawContext& ctx){std::lock_guard<std::mutex> guard(menuLock);menu.draw(ctx,backend);
}
static DWORD WINAPI run(void*){
    wchar_t path[MAX_PATH]{};GetModuleFileNameW(module,path,MAX_PATH);std::wstring base(path);base.resize(base.find_last_of(L"\\/"));folder=base+L"\\CyberwareCombined";CreateDirectoryW(folder.c_str(),nullptr);
    char narrow[MAX_PATH]{};WideCharToMultiByte(CP_ACP,0,folder.c_str(),-1,narrow,MAX_PATH,nullptr,nullptr);
    LogOpen((std::string(narrow)+"\\CyberwareCompanion.log").c_str());SwitchesLoad(narrow);
    menu.layout.standalone=true;menu.layout.load(folder+L"\\settings.ini");profile=folder+L"\\loadout.ini";
    auto source=std::filesystem::exists(profile)?profile:folder+L"\\settings.ini";
    cyberware::loadBanks(source);haveOutfit=cyberware::loadSelection(source,outfit);
    bootstrap=source!=profile;
    if(!haveOutfit)menu.saveStatus=L"Equip a design to save your cyberware";menu.setImageFolder(folder+L"\\Gallery");OverlaySetCallbacks(draw,key);
    Log("Cyberware companion waiting for Character Creator startup");
    Sleep(15000);Log("Cyberware verifying mounted resources");backend.initialize((folder+L"\\recovery.ini").c_str());
    if(!OverlayInit()){Log("combined menu overlay failed");return 0;}
    Log("Saved cyberware restoration active for eligible DamiElf");
    bool held=false,middleUsed=false;ULONGLONG middleSince=0;
    for(;;){
        {std::lock_guard<std::mutex> guard(menuLock);if(menu.session.visible&&menu.session.canceling&&menu.session.cancel(backend)){remember(menu.session.preview);OverlaySetVisible(false);}reconcile();}
        DWORD pid=0;GetWindowThreadProcessId(GetForegroundWindow(),&pid);
        CURSORINFO cursor{sizeof(CURSORINFO)};
        OverlaySetDrawing(pid==GetCurrentProcessId()&&GetCursorInfo(&cursor)&&(cursor.flags&CURSOR_SHOWING));
        bool down=pid==GetCurrentProcessId()&&(GetAsyncKeyState(VK_SHIFT)&0x8000)&&(GetAsyncKeyState(VK_F10)&0x8000)&&!(GetAsyncKeyState(VK_CONTROL)&0x8000)&&!(GetAsyncKeyState(VK_MENU)&0x8000);
        bool middle=pid==GetCurrentProcessId()&&(GetAsyncKeyState(VK_MBUTTON)&0x8000);
        if(!middle){middleSince=0;middleUsed=false;}
        else if(!middleSince)middleSince=GetTickCount64();
        bool mouseOpen=middle&&!middleUsed&&GetTickCount64()-middleSince>=600;
        if(mouseOpen)middleUsed=true;
        HWND requested=(HWND)InterlockedExchangePointer(&requestedWindow,nullptr);
        {
            std::lock_guard<std::mutex> guard(menuLock);
            if(!menu.session.visible&&(requested||mouseOpen||(down&&!held)))beginGallery();
            else if(menu.session.visible&&down&&!held&&!menu.session.canceling){menu.session.visible=false;OverlaySetVisible(false);}
        }
        OverlayFrame(requested?requested:pid==GetCurrentProcessId()?GetForegroundWindow():nullptr);
        held=down;Sleep(8);
    }
}
BOOL WINAPI DllMain(HINSTANCE instance,DWORD reason,LPVOID){
    if(reason==DLL_PROCESS_ATTACH){wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);const wchar_t* name=wcsrchr(path,L'\\');name=name?name+1:path;if(_wcsicmp(name,L"CrimsonDesert.exe"))return TRUE;module=instance;DisableThreadLibraryCalls(instance);HANDLE thread=CreateThread(nullptr,0,run,nullptr,0,nullptr);if(thread)CloseHandle(thread);}return TRUE;
}






