#pragma once
#include <array>
#include <cstdint>
#include "menu_state.h"
#include "native_catalog.h"
namespace cyberware {
using Look=std::array<uint8_t,16>;
inline unsigned Mask(const Selection& s){unsigned m=0;for(size_t i=0;i<7;i++)if(s.enabled[i])m|=1u<<i;return m;}
inline unsigned PlateCoverage(const Selection& s){
    if(s.enabled[5]&&unsigned(s.finishes[5])>=7)return 4;
    return unsigned(s.enabled[6])+2*unsigned(s.enabled[5]);
}
inline bool Encode(const Selection& s,Look& target){
    if(!Valid(s))return false;
    target[4]=target[7]=target[8]=target[9]=target[10]=target[11]=target[12]=target[13]=target[14]=target[15]=0;
    for(size_t i=0;i<DesignCount;i++)if(s.enabled[i]){
        unsigned color=static_cast<unsigned>(s.finishes[i]);
        if(color>=FinishCounts[i])return false;
        unsigned coverage=PlateCoverage(s);
        unsigned index=color<4?DesignBases[i]+color:CustomBases[i]+color-4;
        if(i<5&&coverage)index=CoveredBases[i]+7*(coverage-1)+color;
        target[DesignSlots[i]]=static_cast<uint8_t>(index);
    }
    target[6]=s.enabled[7]?1:BrowOptions[Mask(s)];
    return target[6]!=255;
}
inline bool Decode(const Look& look,Selection& s){
    s={};
    for(int slot:{4,7,8,9,10,11,12,13,14,15}){
        unsigned value=look[slot]==255?0:look[slot];if(!value)continue;
        if(slot==12 && value<=6)continue; // Retired spine from an older appearance.
        bool found=false;
        for(size_t i=0;i<DesignCount;i++){
            if(DesignSlots[i]!=static_cast<unsigned>(slot))continue;
            if(i<5&&value>=CoveredBases[i]&&value<CoveredBases[i]+28){
                s.enabled[i]=true;s.finishes[i]=static_cast<Finish>((value-CoveredBases[i])%7);found=true;break;
            }
            for(unsigned f=0;f<FinishCounts[i];f++){
                if(i==7&&f>0&&f<4)continue;
                unsigned index=f<4?DesignBases[i]+f:CustomBases[i]+f-4;
                if(value==index){s.enabled[i]=true;s.finishes[i]=static_cast<Finish>(f);found=true;break;}
            }
            if(found)break;
        }
        if(!found)return false;
    }
    return Valid(s);
}
struct HairLease {
    bool owned=false;uint8_t original=255;
    uint8_t target(bool scalp,uint8_t current){
        if(scalp){
            if(!owned||current!=255)original=current;
            owned=true;return 255;
        }
        uint8_t result=owned&&current==255?original:current;
        owned=false;return result;
    }
};
inline bool OwnedEqual(const Look& a,const Look& b){
    for(int slot:{0,1,2,4,6,7,8,9,10,11,12,13,14,15})if(a[slot]!=b[slot])return false;
    return true;
}
inline bool QueueSlot(int slot,const Look& from,const Look& to){
    bool scalpWasOn=from[8]!=0&&from[8]!=255,scalpNowOn=to[8]!=0&&to[8]!=255;
    bool hairChange=from[2]!=to[2]||(!scalpWasOn&&scalpNowOn&&to[2]==255);
    // A new hairstyle can supply its own brows. Reassert the union mask in
    // the same transaction, even when the eyebrow option number is unchanged.
    return from[slot]!=to[slot]||((slot==2||slot==6)&&hairChange);
}
struct Request {
    bool pending=false;Look before{},desired{};uint32_t started=0;
    void begin(const Look& from,const Look& to,uint32_t now){before=from;desired=to;started=now;pending=true;}
    bool consume(const Look& current,uint32_t now){
        if(!pending)return false;pending=false;
        return uint32_t(now-started)<=1000&&OwnedEqual(before,current)&&before[0]==current[0]&&before[1]==current[1];
    }
};
}

