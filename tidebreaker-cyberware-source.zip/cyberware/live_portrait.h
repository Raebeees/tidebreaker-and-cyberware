#include <dwmapi.h>
#pragma comment(lib,"dwmapi.lib")
static HTHUMBNAIL thumb;
static HWND thumbSource;
static bool portraitShown;
static bool showPortrait(RECT dest,bool full,float cx,float cy,D2D1_RECT_F& bounds){
    if(!game||IsIconic(game))return false;
    if(thumbSource!=game){
        if(thumb)DwmUnregisterThumbnail(thumb);
        thumb=nullptr;thumbSource=nullptr;
        if(FAILED(DwmRegisterThumbnail(editor,game,&thumb)))return false;
        thumbSource=game;
    }
    RECT r{};if(!GetClientRect(game,&r))return false;
    int w=r.right,h=r.bottom,dw=dest.right-dest.left,dh=dest.bottom-dest.top;
    if(w<2||h<2||dw<2||dh<2)return false;
    int sw=w,sh=h;
    if(full){
        double k=(std::min)(double(dw)/w,double(dh)/h);
        int nw=int(w*k+.5),nh=int(h*k+.5);
        dest.left+=(dw-nw)/2;dest.top+=(dh-nh)/2;dest.right=dest.left+nw;dest.bottom=dest.top+nh;
    }else{
        sh=(std::max)(1,h/4);sw=std::clamp(int(double(sh)*dw/dh),1,w);
    }
    int x=std::clamp(int(cx*w)-sw/2,0,w-sw),y=std::clamp(int(cy*h)-sh/2,0,h-sh);
    DWM_THUMBNAIL_PROPERTIES p{};
    p.dwFlags=DWM_TNP_RECTDESTINATION|DWM_TNP_RECTSOURCE|DWM_TNP_VISIBLE|DWM_TNP_SOURCECLIENTAREAONLY;
    p.fVisible=TRUE;p.fSourceClientAreaOnly=TRUE;p.rcSource={x,y,x+sw,y+sh};p.rcDestination=dest;
    if(FAILED(DwmUpdateThumbnailProperties(thumb,&p)))return false;
    bounds=D2D1::RectF(float(dest.left),float(dest.top),float(dest.right),float(dest.bottom));
    portraitShown=true;return true;
}
static void hidePortrait(){
    if(!thumb)return;
    DWM_THUMBNAIL_PROPERTIES p{};p.dwFlags=DWM_TNP_VISIBLE;DwmUpdateThumbnailProperties(thumb,&p);
}
