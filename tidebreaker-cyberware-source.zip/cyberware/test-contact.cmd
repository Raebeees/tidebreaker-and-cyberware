@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cd /d "%~dp0"
cl /nologo /std:c++17 /O2 /EHsc /DUNICODE /D_UNICODE test_contact.cpp /Fe:build/test_contact.exe /link user32.lib >build/contact-build.log 2>&1
if errorlevel 1 exit /b 1
build\test_contact.exe "%~dp0.."
exit /b %errorlevel%
