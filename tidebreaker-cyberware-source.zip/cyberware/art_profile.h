#pragma once
#include <string>
#include <array>
#include <atomic>
#include <cwchar>
#include <windows.h>
#include "art_catalog.h"
#include "rgb_finish.h"
namespace cyberware {
struct ArtProfile {
    int color=0,normal=0,metal=1,rough=1;bool custom=false;
    bool valid(unsigned d) const {
        if(d>=std::size(ArtLists))return false;
        auto &list=ArtLists[d];
        if(color<0||color>=list.colorCount||normal<0||normal>=list.normalCount||metal<0||metal>6||rough<0||rough>6)return false;
        if(metal>2||rough>2){if(d!=6||(wcscmp(list.normals[normal].name,L"Original")&&wcscmp(list.normals[normal].name,L"Smooth")))return false;}
        return d!=5||!wcscmp(list.colors[color].style,list.normals[normal].style);
    }
    unsigned pack() const {return 1u+color+(normal<<6)+(metal<<10)+(rough<<13)+(unsigned(custom)<<16);}
    static ArtProfile unpack(unsigned v){--v;return {int(v&63),int((v>>6)&15),int((v>>10)&7),int((v>>13)&7),bool(v&(1u<<16))};}
};
inline std::atomic<unsigned> materialBanks[8][6]{};
inline std::atomic<unsigned> materialReads[8][6]{};
inline void recordMaterialRead(unsigned design,unsigned bank,unsigned value,unsigned channel){
    auto &seen=materialReads[design][bank];auto before=seen.load();
    while(materialBanks[design][bank].load()==value){
        auto after=(value<<3)|channel|((before>>3)==value?(before&7):0);
        if(seen.compare_exchange_weak(before,after))break;
    }
}
inline bool materialSeen(unsigned d,unsigned finish){
    if(finish<4||d>=8)return true;
    auto b=finish-4;auto profile=materialBanks[d][b].load();
    return profile&&materialReads[d][b].load()==((profile<<3)|7);
}
inline std::atomic<bool> artReady{false};
inline std::wstring artSettings;
inline RgbFinish rgbBanks[8][6];
inline bool saveBanksTo(const std::wstring& path){
    for(unsigned d=0;d<8;d++)for(unsigned b=0;b<6;b++){
        wchar_t key[20],val[20];swprintf_s(key,L"Art%uBank%u",d,b);swprintf_s(val,L"%u",materialBanks[d][b].load());
        if(!WritePrivateProfileStringW(L"Materials",key,val,path.c_str()))return false;
        const auto& c=rgbBanks[d][b];wchar_t rgb[80];swprintf_s(rgb,L"%d,%d,%d,%d,%d,%d",c.r,c.g,c.b,c.brightness,c.metal,c.rough);
        if(!WritePrivateProfileStringW(L"RGB",key,rgb,path.c_str()))return false;
    }
    return true;
}
inline void loadBanks(const std::wstring& path){
    artSettings=path;
    for(unsigned d=0;d<8;d++)for(unsigned b=0;b<6;b++){
        wchar_t key[20];swprintf_s(key,L"Art%uBank%u",d,b);
        wchar_t rgb[80];RgbFinish c;GetPrivateProfileStringW(L"RGB",key,L"",rgb,80,path.c_str());
        if(swscanf_s(rgb,L"%d,%d,%d,%d,%d,%d",&c.r,&c.g,&c.b,&c.brightness,&c.metal,&c.rough)==6&&c.valid())rgbBanks[d][b]=c;
        auto value=GetPrivateProfileIntW(L"Materials",key,0,path.c_str());
        if(value&&ArtProfile::unpack(value).valid(d))materialBanks[d][b]=value;
    }
}
bool InstallMaterialReader();
}






