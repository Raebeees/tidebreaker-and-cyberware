#include <windows.h>
#include <wincodec.h>
#include <algorithm>
#include "desktop_overlay.h"
#include "log.h"
extern bool GalleryPointer(HWND,UINT,LPARAM);
extern "C" void WINAPI OpenCyberwareGallery(HWND);
static void (*g_draw)(const OverlayDrawContext&);
static void (*g_key)(int);
static volatile LONG visible=0,drawing=0;
static HWND editor,launcher,game;
static ID2D1Factory* factory;
static ID2D1DCRenderTarget* target;
static IDWriteFactory* fonts;
static IWICImagingFactory* wic;
static unsigned generation=1;
#include "live_portrait.h"
static bool paint(HWND hwnd,HDC dc){
    RECT rc{};GetClientRect(hwnd,&rc);
    if(!target){
        auto props=D2D1::RenderTargetProperties(D2D1_RENDER_TARGET_TYPE_SOFTWARE,D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM,D2D1_ALPHA_MODE_IGNORE),96,96);
        if(FAILED(factory->CreateDCRenderTarget(&props,&target)))return false;
    }
    if(!rc.right||!rc.bottom||FAILED(target->BindDC(dc,&rc)))return false;
    portraitShown=false;target->BeginDraw();target->Clear(D2D1::ColorF(0x16191d));g_draw({target,fonts,float(rc.right),float(rc.bottom),generation,showPortrait});
    if(!portraitShown)hidePortrait();
    auto hr=target->EndDraw();if(hr==D2DERR_RECREATE_TARGET){target->Release();target=nullptr;++generation;}
    return SUCCEEDED(hr);
}
static LRESULT CALLBACK windowProc(HWND hwnd,UINT msg,WPARAM wp,LPARAM lp){
    if(hwnd==launcher&&launcher){
        if(msg==WM_LBUTTONUP){OpenCyberwareGallery(game);return 0;}
        if(msg==WM_MOUSEACTIVATE)return MA_NOACTIVATE;
        if(msg==WM_PAINT){PAINTSTRUCT ps;HDC dc=BeginPaint(hwnd,&ps);RECT r{};GetClientRect(hwnd,&r);
            SetBkColor(dc,RGB(32,35,40));SetTextColor(dc,RGB(248,222,175));ExtTextOutW(dc,0,0,ETO_OPAQUE,&r,nullptr,0,nullptr);
            DrawTextW(dc,L"Cyberware",-1,&r,DT_CENTER|DT_VCENTER|DT_SINGLELINE);EndPaint(hwnd,&ps);return 0;}
    }
    if(hwnd==editor&&editor){
        if(msg==WM_PAINT){PAINTSTRUCT ps;auto dc=BeginPaint(hwnd,&ps);paint(hwnd,dc);EndPaint(hwnd,&ps);return 0;}
        if(msg==WM_PRINTCLIENT)return paint(hwnd,(HDC)wp);
        if(msg==WM_ERASEBKGND)return 1;
        if(msg==WM_CLOSE){g_key(VK_ESCAPE);return 0;}
        if(msg==WM_KEYDOWN){g_key(int(wp));return 0;}
        if(msg==WM_LBUTTONDOWN||msg==WM_LBUTTONUP||msg==WM_MOUSEMOVE||msg==WM_CAPTURECHANGED||msg==WM_CANCELMODE){
            if(msg==WM_LBUTTONDOWN)SetCapture(hwnd);
            GalleryPointer(hwnd,msg,lp);
            if(msg==WM_LBUTTONUP&&GetCapture()==hwnd)ReleaseCapture();
            return 0;
        }
    }
    return DefWindowProcW(hwnd,msg,wp,lp);
}
void OverlaySetCallbacks(void(*d)(const OverlayDrawContext&),void(*k)(int)){g_draw=d;g_key=k;}
void OverlaySetVisible(bool v){InterlockedExchange(&visible,v);}
void OverlaySetDrawing(bool v){InterlockedExchange(&drawing,v);}
bool OverlayInit(){
    if(FAILED(CoInitializeEx(nullptr,COINIT_APARTMENTTHREADED)))return false;
    if(FAILED(D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED,&factory))||
       FAILED(DWriteCreateFactory(DWRITE_FACTORY_TYPE_SHARED,__uuidof(IDWriteFactory),(IUnknown**)&fonts))||
       FAILED(CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&wic))))return false;
    WNDCLASSW wc{};wc.hInstance=GetModuleHandleW(nullptr);wc.lpfnWndProc=windowProc;wc.lpszClassName=L"CyberwareBodyAreasWindow";wc.hCursor=LoadCursor(nullptr,IDC_ARROW);
    if(!RegisterClassW(&wc))return false;
    editor=CreateWindowExW(WS_EX_TOOLWINDOW,wc.lpszClassName,L"Cyberware  /  Body Areas",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_THICKFRAME,0,0,790,490,nullptr,nullptr,wc.hInstance,nullptr);
    launcher=CreateWindowExW(WS_EX_TOOLWINDOW|WS_EX_NOACTIVATE,wc.lpszClassName,L"Cyberware",WS_POPUP,0,0,128,34,nullptr,nullptr,wc.hInstance,nullptr);
    return editor&&launcher;
}
ID2D1Bitmap* OverlayLoadImage(const wchar_t* path){
    IWICBitmapDecoder* decoder=nullptr;IWICBitmapFrameDecode* frame=nullptr;IWICFormatConverter* converter=nullptr;ID2D1Bitmap* bitmap=nullptr;
    if(target&&SUCCEEDED(wic->CreateDecoderFromFilename(path,nullptr,GENERIC_READ,WICDecodeMetadataCacheOnLoad,&decoder))
        &&SUCCEEDED(decoder->GetFrame(0,&frame))&&SUCCEEDED(wic->CreateFormatConverter(&converter))
        &&SUCCEEDED(converter->Initialize(frame,GUID_WICPixelFormat32bppPBGRA,WICBitmapDitherTypeNone,nullptr,0,WICBitmapPaletteTypeCustom)))
        target->CreateBitmapFromWicBitmap(converter,nullptr,&bitmap);
    if(converter)converter->Release();if(frame)frame->Release();if(decoder)decoder->Release();return bitmap;
}

void OverlayFrame(HWND active){
    MSG msg;while(PeekMessageW(&msg,nullptr,0,0,PM_REMOVE)){TranslateMessage(&msg);DispatchMessageW(&msg);}
    RECT r{};if(active&&active!=editor&&active!=launcher&&GetClientRect(active,&r)&&r.right>=640&&r.bottom>=360&&!(GetWindowLongPtrW(active,GWL_EXSTYLE)&WS_EX_TOOLWINDOW))game=active;
    if(!game||!IsWindow(game))return;
    if(visible){
        if(IsWindowVisible(launcher))ShowWindow(launcher,SW_HIDE);
        if(!IsWindowVisible(editor)){
            static bool placed=false;SetWindowLongPtrW(editor,GWLP_HWNDPARENT,(LONG_PTR)game);
            if(!placed){GetWindowRect(game,&r);int w=(std::min)(800L,r.right-r.left),h=(std::min)(495L,r.bottom-r.top);
                SetWindowPos(editor,nullptr,r.right-w-12,r.top+(r.bottom-r.top-h)/2,w,h,SWP_NOZORDER|SWP_NOACTIVATE);placed=true;}
            ShowWindow(editor,SW_SHOWNORMAL);SetForegroundWindow(editor);SetFocus(editor);
            Log("Body Areas editor opened in its own window");
        }
        static ULONGLONG last=0;auto now=GetTickCount64();if(now-last>=32){InvalidateRect(editor,nullptr,FALSE);last=now;}
        return;
    }
    if(IsWindowVisible(editor)){bool restore=GetForegroundWindow()==editor;ShowWindow(editor,SW_HIDE);if(restore)SetForegroundWindow(game);}
    if(active==game&&drawing&&!IsIconic(game)){
        GetClientRect(game,&r);POINT p{r.right-140,12};ClientToScreen(game,&p);
        if(GetWindow(launcher,GW_OWNER)!=game)SetWindowLongPtrW(launcher,GWLP_HWNDPARENT,(LONG_PTR)game);
        SetWindowPos(launcher,HWND_TOP, p.x,p.y,128,34,SWP_NOACTIVATE|SWP_SHOWWINDOW);
    }else if(IsWindowVisible(launcher))ShowWindow(launcher,SW_HIDE);
}
